#Author Robin Toloch
#Version 1.03
#Creation date 26. 02. 2020
#Modified date 04. 03. 2020

#Purpose
#This script reads XML file containing deployments and performs necessary steps

#Fixes
#1.01 - corrected query to select already deployed applications
#1.03 - fixed a bug where collection names were not recognized properly for include or exclude rules

#New features
#1.02 
#- 01. 03. 2020
#- added settings file to dynamically read server and site name. this allows users to run the application outside sccm server. The values can be changed using deploymentcreator.

#1.03
#- 04. 03. 2020
#added settings for device and user collection paths to allow to move the created collections to a different SCCM folder
#user collections can no longer be targeted by a mandatory deployment of any kind
#comment on collections is now Reason parameter of the deployment instead of "This collection was created by AutoScript.ps1"



$Global:logFile = "$($PSScriptRoot)\LogData\autoScript.log"
$Global:settingsObject = [PSCustomObject]@{"ServerName"="";"SiteName"="";"DeviceColPath"="";"UserColPath"=""}

#simple log to cm trace file function
function LogToCMTraceFile {
    param (
        [Parameter(Mandatory=$true)]
        [ValidateNotNull()]
        [string]$message,

        [Parameter(Mandatory=$true)]
        [ValidateNotNull()]
        [int]$type,

        #1 - information
        #2 - warning
        #3 - error
        #4 - verbose


        [Parameter(Mandatory=$true)]
        [ValidateNotNull()]
        [string]$component,

        [Parameter(Mandatory=$false)]
        [int]$thread,

        [Parameter(Mandatory=$false)]
        [string]$file
    )
    If($type -lt 1 -or $type -gt 4) {
        Throw "Type must be between 1-4"
    }
    If($file -ne "" -and $thread -eq ""){
        Throw "You must specify thread, if you wish to use -file switch"
    }

    $Time = (Get-Date -Format "HH:mm:ss.fff-fff")
    $Date = (Get-Date -Format "MM-dd-yyyy")

    $LogStructure = "<![LOG[$($message)]LOG]!><time=""$($Time)"" date=""$($Date)"" component=""$($component)"" context="""" type=""$($type)"" thread=""$($hread)"" file=""$($file)"">"
    createFolderStructure -path $Global:logFile.Substring(0,$Global:logFile.LastIndexOf("\")) | Out-Null
    Out-File -FilePath $Global:logFile -Append -InputObject $LogStructure -Force -Encoding utf8
}

Function MoveSCCMItem {
    param (
        $objectID,
        $parentFolderID,
        $targetFolderID,
        $objectType
    )
    
    try {
        LogToCMTraceFile -type 1 -component "MoveSCCMItem" -message "Beginning function MoveSCCMItem"
        $objectToMoveExists = $false
        #try to grab the object in SCCM to see if it even exists
        switch ($objectType) {
            {($_ -eq 5000) -or ($_ -eq 5001)} {
                #5000 - device collection
                #5001 - user collection
                $collectionType = $null
                if ($objectType -eq 5000) {
                    $collectionType = 2
                    LogToCMTraceFile -type 1 -component "MoveSCCMItem" -message "- collection type is of device"
                } elseif ($objectType -eq 5001) {
                    $collectionType = 1
                    LogToCMTraceFile -type 1 -component "MoveSCCMItem" -message "- collection type is of user"
                }
                $collectionObject = Get-WmiObject -Namespace "root\sms\site_$($Global:settingsObject.SiteName)" -ComputerName $Global:settingsObject.ServerName -Query "Select CollectionID from SMS_COLLECTION where CollectionID='$objectID' and collectiontype='$collectionType'"
                if ($collectionObject -ne $null) {
                    $objectToMoveExists = $true
                    LogToCMTraceFile -type 1 -component "MoveSCCMItem" -message "- collection exists in SCCM"
                } else {
                    $objectToMoveExists = $false
                }
            }

            #add other objects - package & application
        }
        #exit the function if the object does not exist
        if ($objectToMoveExists -eq $false) {
            LogToCMTraceFile -type 2 -component "MoveSCCMItem" -message "- object does not exist. Quitting!"
            return $false
        }
        LogToCMTraceFile -type 1 -component "MoveSCCMItem" -message "- current target folder is $($parentFolderID)"
        #get the parent folder if it was not specified
        if ($parentFolderID -eq $null) {
            $containerItemObject = Get-WmiObject -Namespace "root\sms\site_$($Global:settingsObject.SiteName)" -ComputerName $Global:settingsObject.ServerName -Query "Select ContainerNodeID From SMS_ObjectContainerItem Where InstanceKey='$objectID' and ObjectType='$objectType'"
            if ($containerItemObject -eq $null) {
                #item does not exist in any folder = it is in the root because the object exists (based on the code from earlier)
                $parentFolderID = 0        
            } else {
                $parentFolderID = $containerItemObject.ContainerNodeID
            }
        }
        LogToCMTraceFile -type 1 -component "MoveSCCMItem" -message "- object target folder is now $($parentFolderID)"        
        if ($parentFolderID -eq $null) {
            #parent is still null after previous condition check, quit function
            LogToCMTraceFile -type 2 -component "MoveSCCMItem" -message "- target folder is still empty. Quitting!"        
            return $false
        }

        LogToCMTraceFile -type 1 -component "MoveSCCMItem" -message "- getting SCCM class"        
        $objectItemClass = [wmiClass]"\\$($Global:settingsObject.ServerName)\root\sms\site_$($Global:settingsObject.SiteName):SMS_ObjectContainerItem"
        LogToCMTraceFile -type 1 -component "MoveSCCMItem" -message "- preparing parameters"
        $moveMembersParameters = $objectItemClass.GetMethodParameters("MoveMembers")
        $moveMembersParameters.ContainerNodeID = $parentFolderID
        $moveMembersParameters.InstanceKeys = $objectID
        $moveMembersParameters.ObjectType = $objectType
        $moveMembersParameters.TargetContainerNodeID = $targetFolderID
        LogToCMTraceFile -type 1 -component "MoveSCCMItem" -message "- moving the object"
        $objectItemClass.PSBase.InvokeMethod("MoveMembers",$moveMembersParameters,$null) | Out-Null
        LogToCMTraceFile -type 1 -component "MoveSCCMItem" -message "- action was successful"
        return $true

    } catch {
        LogToCMTraceFile -type 3 -component "MoveSCCMItem" -message "- moving the object was not successful! Error message: $($_.Exception.Message)"
        return $false
    }
}

Function GetTargetFolderID {
    #this function creates folder structure passed to TargetFolder parameter and returns the last folder's id
    #it takes target folder and object type as parameters.
    #target folder can be "root\software distribution\!CORE APPS"
    #it first creates a dummy array for folderObjects which will hold objects with FolderName=XXX and FolderID=XXX properties

    #tempPath variable is declared before foreach to hold parts that are put back together later on
    #it then splits target folder by \ and goes through each item
    
    #first item is always root and script creates object for the array FolderName=root FolderID=0. tempPath is set to root
        #next item is another folder, in our example software distribution
        #it will get its parent id which is root-0 by querying folderObjects array for FolderID where FolderName=$tempPath, tempPath is set to tempPath\$item
        #script then tries to get folderId by using GetFolderID function which tries to find FolderID (ContainerID) for folder where Name=$item and parentID (ParentContainerNodeID)=$parentID
        #if folderID is returned an object is saved to the array FolderName=$tempPath FolderID=returnedID
        #if no folder is found, it creates one and adds it to the array
            #it then repeats it for every other item in the list
            #in our example the last folder is !CORE APPS
            #script finds parentID from folderObjects where parent name = root\software distribution, it finds it and tries to find folder with name !CORE APPS and parent id of root\software distribution
            #folder found = saved to array, folder not found = it is created and saved to the array

    #the function returns FolderID of last item in folderObjects. The AutoScript then uses the folderID to put collections to

    param (
        $targetFolder,
        $objectType
    )
    $targetFolderParts = $targetFolder.Split("\")
    LogToCMTraceFile -type 1 -component "folder checker" -message "Running function to get target folder ID of $($targetFolder). Object type: $($objectType)"
    $folderObjects = @()
    #[PSCustomObject]@{"FolderName"=XX,"FolderID"=id}
    $tempPath = ""
    foreach ($part in $targetFolderParts) {
        LogToCMTraceFile -type 1 -component "folder checker" -message "-------------"
        $part = $part.Trim()
        if ($part -eq "") {
            LogToCMTraceFile -type 1 -component "folder checker" -message "empty part, continue"
            continue
        }
        if ($part -eq "root" -and $tempPath -eq "") { 
            #create item in folderObjects for root where FolderID is 0 and continue with next folder name
            LogToCMTraceFile -type 1 -component "folder checker" -message "root, folder id 0"
            $tempPath = "root"
            $folderObjects += [PSCustomObject]@{"FolderName"="root";"FolderID"=0}
            continue
        } elseif ($part -ne "root" -and $tempPath -eq "") {
            LogToCMTraceFile -type 2 -component "folder checker" -message "first folder is not root - invalid path. setting the target folder to 0 (root)"
            return 0
        }
        #parent of the item is tempPath because it is modified at the end of foreach...
        $parent = $tempPath
        LogToCMTraceFile -type 1 -component "folder checker" -message "folder parent $parent"
        #select id of the parent from the object by querying for FolderName in folderObjects array and select FolderID
        $parentID = ($folderObjects | Where {$_.FolderName -eq $parent}).FolderID
        LogToCMTraceFile -type 1 -component "folder checker" -message "parent id $parentID"
        #change tempPath (full folder name) and append the folder name
        $tempPath+= "\$($part)"
        LogToCMTraceFile -type 1 -component "folder checker" -message "folder to process $part"
        LogToCMTraceFile -type 1 -component "folder checker" -message "path to the folder $tempPath"
        #get id of the folder to process using getFolderID function

        $folderID = getFolderID -folderName $part -parentFolderID $parentID -objectType $objectType
        #function getFolderID returns false if it ran into an error. this will quit the function and return 0
        #this is because we cannot know whether the folder exists or not
        if ($folderID -eq $false) { return 0 }

        if ($folderID -ne $Null) {
            #folder was found, put full folder name and its id to the array
            #add it at the end so that we dont have duplicate commands. this scriptblock is not even needed anymore.
            LogToCMTraceFile -type 1 -component "folder checker" -message "folder $part found"
        } else {
            #folder does not exist, create it and put to the array the details
            try {
                LogToCMTraceFile -type 1 -component "folder checker" -message "folder $part not found - it has to be created"
                $newFolder = ([wmiClass]"\\$($Global:settingsObject.ServerName)\root\sms\site_$($Global:settingsObject.SiteName):SMS_ObjectContainerNode").CreateInstance()
                $newFolder.ObjectType = $objectType
                $newFolder.Name = $part
                $newFolder.ParentContainerNodeID = $parentID
                $newFolder = $newFolder.Put()
                $folderID = $newFolder.RelativePath.Substring($newFolder.RelativePath.IndexOf("=")+1,$newFolder.RelativePath.Length - $newFolder.RelativePath.IndexOf("=") -1)
            } catch {
                #error creating the folder, exit 0 to tell script to create it at root level
                return 0
            }
        }
        $folderObjects += [PSCustomObject]@{"FolderName"=$tempPath;"FolderID"=$folderID}
        LogToCMTraceFile -type 1 -component "folder checker" -message "processed folder id: $folderID"
    }
    LogToCMTraceFile -type 1 -component "folder checker" -message "target folder id: $($folderObjects[$folderObjects.Count-1].FolderID)"
    return $folderObjects[$folderObjects.Count-1].FolderID
}
Function getFolderID {
    param (
        $folderName,
        $parentFolderID,
        $objectType
    )
    try {
        return (Get-WmiObject -Namespace "root\sms\site_$($Global:settingsObject.SiteName)" -ComputerName $Global:settingsObject.ServerName -Query "select ContainerNodeID from SMS_ObjectContainerNode where name='$($folderName)' and ObjectType='$($objectType)' and ParentContainerNodeID='$($parentFolderID)'").ContainerNodeID
    } catch {
        return $false
    }
}

Function validSettings {
    param ( $inputSettingsObject )

    if ($inputSettingsObject.serverName -eq $null -or $inputSettingsObject.siteName -eq $null -or $inputSettingsObject.siteName.Length -gt 3 -or $inputSettingsObject.DeviceColPath -eq $null -or $inputSettingsObject.UserColPath -eq $null) {
        return $false
    } else {
        return $true
    }
}

Function readSettingsXML {
    try {
        LogToCMTraceFile -message "Reading settings file" -type 1 -component "settingsRead"
        #reads and returns object with properties
        #PSCustomObject | ServerName=xxxx;SiteName=xxx
        $settingsFilePath = "$($PSScriptRoot)\settings.xml"
        if ((Test-Path -Path $settingsFilePath) -eq $true) {
            [xml]$settingsFile = Get-Content -Path $settingsFilePath
            $serverName = $settingsFile.appSettings.ServerName
            $siteName = $settingsFile.appSettings.SiteName
            $devColPath = $settingsFile.appSettings.DeviceCollectionPath
            $userColPath = $settingsFile.appSettings.UserCollectionPath
            if ($serverName -eq $null -or $siteName -eq $null -or $siteName.Length -gt 3 -or $devColPath -eq $null -or $userColPath -eq $null) {
                LogToCMTraceFile -message "-- invalid settings. Server name: $($serverName), Site name: $($siteName), Device collection path: $($devColPath), User collection path: $($userColPath)" -type 2 -component "settingsRead"
            } else {
                LogToCMTraceFile -message "-- successfully retrieved settings. Server name: $($serverName), Site name: $($siteName), Device collection path: $($devColPath), User collection path: $($userColPath)" -type 1 -component "settingsRead"
            }
            return [PSCustomObject]@{"ServerName"=$serverName;"SiteName"=$siteName;"DeviceColPath"=$devColPath;"UserColPath"=$userColPath}
        } else {
            LogToCMTraceFile -message "-- the settings file does not exist" -type 2 -component "settingsRead"
            return $false
        }
    } catch {
        LogToCMTraceFile -message "-- error reading the file. Error message $($_.exception.message)" -type 3 -component "settingsRead"
        return 1
    }
}

Function createFolderStructure {
    #function to create folder structure for given path, the path should not end with \ and should not contain file name
    param (
        [string]$path
    )
    if ((Test-Path -Path $path) -eq $true) { return $true }
    $pathBuilder = ""
    foreach ($part in $path.Split("\")) {
        $pathBuilder+=$part + "\"
        if ((Test-Path -Path $pathBuilder) -eq $false) {
            New-Item -Path $pathBuilder -ItemType "directory" -Force | Out-Null
        }
    }
    LogToCMTraceFile -message "Creating folder structure for $($path)" -type 1 -component "folderCreator"
}

Function removeCollection {
    param (
        $collectionID
    ) 
    try {
        LogToCMTraceFile -message "Removing collection id $($collectionID)" -type 1 -component "collectionRemoval"
        $collectionObject = Get-WmiObject -Namespace "root\sms\site_$($Global:settingsObject.SiteName)" -ComputerName $Global:settingsObject.ServerName -Query "Select * from SMS_COLLECTION where collectionid='$($collectionID)'"
        if ($collectionObject -ne $null) {
            LogToCMTraceFile -message "--- collection found in SCCM. Removing..." -type 1 -component "collectionRemoval"
            $collectionObject | Remove-WmiObject
            LogToCMTraceFile -message "--- successfully removed the collection." -type 1 -component "collectionRemoval"
            return $true
        } else {
            LogToCMTraceFile -message "--- collection was not found in SCCM. Nothing to remove" -type 2 -component "collectionRemoval"
            return $true
        }
    } catch {
        LogToCMTraceFile -message "--- error removing the collection. Eror message: $($_.Exception.Message)" -type 3 -component "collectionRemoval"
        return $false
    }

}

Function createCollection {
    param (
        $collectionName,
        $collectionType,
        $collectionComment
    )
    try {
        LogToCMTraceFile -message "Creating collection for: $($collectionName)" -type 1 -component "collectionCreator"

        if ($collectionType -eq 1) {
            $limitId = (Get-WmiObject -Namespace "root\sms\site_$($Global:settingsObject.SiteName)" -ComputerName $Global:settingsObject.ServerName -Query "select CollectionId from sms_collection where name='All Users and User Groups'").CollectionID
            $collectionName = "UC $($collectionName)"
            LogToCMTraceFile -message "--- user collection name $($collectionName)" -type 1 -component "collectionCreator"
        } elseif ($collectionType -eq 2) {                                                  
            $limitId = (Get-WmiObject -Namespace "root\sms\site_$($Global:settingsObject.SiteName)" -ComputerName $Global:settingsObject.ServerName -Query "select CollectionId from sms_collection where name='All Systems'").CollectionID
            $collectionName = "DC $($collectionName)"
            LogToCMTraceFile -message "--- device collection name $($collectionName)" -type 1 -component "collectionCreator"
        }
        $newCollection = ([wmiClass]"\\$($Global:settingsObject.ServerName)\root\sms\site_$($Global:settingsObject.SiteName):SMS_COLLECTION").CreateInstance()

        $newCollection.Name = $collectionName
        $newCollection.CollectionType = $collectionType
        $newCollection.Comment = $collectionComment
    
        $newCollection.LimitToCollectionID = $limitId

        $newCollection.RefreshType = 2

        $newRefreshSchedule = ([wmiClass]"\\$($Global:settingsObject.ServerName)\root\sms\site_$($Global:settingsObject.SiteName):SMS_ST_RecurInterval").CreateInstance()
        $newRefreshSchedule.DaySpan = 1
        $newRefreshSchedule.StartTime = "$(Get-Date -Format "yyyyMMdd090000").000000+***"
        $newCollection.RefreshSchedule = $newRefreshSchedule
    
        $newCollection.Put() | Out-Null
        LogToCMTraceFile -message "--- collection was created successfully" -type 1 -component "collectionCreator"
        
        return (Get-WmiObject -Namespace "root\sms\site_$($Global:settingsObject.SiteName)" -ComputerName $Global:settingsObject.ServerName -Query "select collectionid from sms_collection where name='$collectionName' and collectiontype='$collectionType'").CollectionID
    } catch {
        LogToCMTraceFile -message "--- error creating the collection. Error message: $($_.Exception.Message)" -type 3 -component "collectionCreator"
        return $false
    }
}

Function createCollectionMembership {
    #this function returns collection RULE object
    param (
        #target collection
        $collectionID,

        #directComputer,User/include (col)/exclude (col)/query
        $ruleType,

        #computer/user/collection name
        $ruleName
    )
    LogToCMTraceFile -message "Creating a new rule $ruleType for $ruleName. Collection $collectionID" -type 1 -component "membershipCreator"
    #get collection fullColObj
    #not needed, see the end of the function
    #$collectionObject = [wmi](Get-WmiObject -Namespace "root\sms\site_$($Global:settingsObject.SiteName)" -ComputerName $Global:settingsObject.ServerName -Query "Select * from SMS_COLLECTION where CollectionId='$collectionid'").__PATH
    $newRule = $false
    try {
        switch ($ruleType) {
            "directComputer" {
                $computerResource = Get-WmiObject -Namespace "root\sms\site_$($Global:settingsObject.SiteName)" -ComputerName $Global:settingsObject.ServerName -Query "select resourceid from sms_r_system where name='$($ruleName)'"
                #new rule
                if ($computerResource -ne $null) {
                    $newRule = ([wmiClass]"\\$($Global:settingsObject.ServerName)\root\sms\site_$($Global:settingsObject.SiteName):SMS_CollectionRuleDirect").CreateInstance()
                    $newRule.ResourceID = $computerResource.ResourceID
                    $newRule.RuleName = $ruleName
                    $newRule.ResourceClassName = "SMS_R_SYSTEM"
                } else {
                    LogToCMTraceFile -message "--- computer not found in SCCM" -type 2 -component "membershipCreator"
                }
            }
            "directUser" {
                $userResource = Get-WmiObject -Namespace "root\sms\site_$($Global:settingsObject.SiteName)" -ComputerName $Global:settingsObject.ServerName -Query "select resourceid from sms_r_user where UniqueUserName like '%\\$($ruleName)'"
                #new rule
                if ($userResource -ne $null) {
                    $newRule = ([wmiClass]"\\$($Global:settingsObject.ServerName)\root\sms\site_$($Global:settingsObject.SiteName):SMS_CollectionRuleDirect").CreateInstance()
                    $newRule.ResourceID = $userResource.ResourceID
                    $newRule.RuleName = $ruleName
                    $newRule.ResourceClassName = "SMS_R_USER"
                } else {
                    LogToCMTraceFile -message "--- user not found in SCCM" -type 2 -component "membershipCreator"
                }
            }
            {($_ -like "include*")} {
                #new rule
                $foundCollection = $null
                if ($ruleType -eq "includeUserCol") {
                    $foundCollection = (Get-WmiObject -Namespace "root\sms\site_$($Global:settingsObject.SiteName)" -ComputerName $Global:settingsObject.ServerName -Query "select collectionid from sms_collection where collectiontype='1' and name='$ruleName'").CollectionID
                } elseif ($ruleType -eq "includeDeviceCol") {
                    $foundCollection = (Get-WmiObject -Namespace "root\sms\site_$($Global:settingsObject.SiteName)" -ComputerName $Global:settingsObject.ServerName -Query "select collectionid from sms_collection where collectiontype='2' and name='$ruleName'").CollectionID
                }

                if ($foundCollection -ne $null) {
                    $newRule = ([wmiClass]"\\$($Global:settingsObject.ServerName)\root\sms\site_$($Global:settingsObject.SiteName):SMS_CollectionRuleIncludeCollection").CreateInstance()
                    $newRule.IncludeCollectionID = $foundCollection
                    $newRule.RuleName = "Include_$foundCollection"
                }
            }
            {($_ -like "exclude*")} {
                #new rule
                $foundCollection = $null
                if ($ruleType -eq "excludeUserCol") {
                    $foundCollection = (Get-WmiObject -Namespace "root\sms\site_$($Global:settingsObject.SiteName)" -ComputerName $Global:settingsObject.ServerName -Query "select collectionid from sms_collection where collectiontype='1' and name='$ruleName'").CollectionID
                } elseif ($ruleType -eq "excludeDeviceCol") {
                    $foundCollection = (Get-WmiObject -Namespace "root\sms\site_$($Global:settingsObject.SiteName)" -ComputerName $Global:settingsObject.ServerName -Query "select collectionid from sms_collection where collectiontype='2' and name='$ruleName'").CollectionID
                }

                if ($foundCollection -ne $null) {
                    $newRule = ([wmiClass]"\\$($Global:settingsObject.ServerName)\root\sms\site_$($Global:settingsObject.SiteName):SMS_CollectionRuleExcludeCollection").CreateInstance()
                    $newRule.ExcludeCollectionID = $foundCollection
                    $newRule.RuleName = "Exclude_$foundCollection"
                }
            }
            {($_ -like "query*")} {
                $finalQuery = ""
                
                if ($ruleType -eq "queryUser") {
                    #for AD
                    #add settings for domain to avoid % like operator for domain part
                    $userQuery = "Select ResourceID,Name from SMS_R_USER where usergroupname like '%\\$ruleName'"
                    $finalQuery = $userQuery
                } elseif($ruleType -eq "queryDevice") {
                    $computerQuery = "Select ResourceID,Name from SMS_R_SYSTEM where systemgroupname like '%\\$ruleName'"
                    $finalQuery = $computerQuery
                }

                if ($finalQuery -ne "") {
                    $newRule = ([wmiClass]"\\$($Global:settingsObject.ServerName)\root\sms\site_$($Global:settingsObject.SiteName):SMS_CollectionRuleQuery").CreateInstance()
                    $newRule.QueryExpression  = $finalQuery
                    $newRule.RuleName = "InGroup_$rulename"
                }
            }
        }
    } catch {
        $newRule = $false
        LogToCMTraceFile -message "---Error creating the rule!" -type 1 -component "membershipCreator"
    }
    #it is better to not do it one by one, but rather have this function return RULE object because it will be faster to create let's say 100 rules first and then add them at once to the collection instead
    #of updating the collection with a new rule 100 times
    #$collectionObject.CollectionRules += $newRule
    #check if collectionid is user/computer
    return $newRule
}

Function CreateApplicationAdvertisement {
    param ( 
        $targetCollectionID,
        $applicationID, #model name - find ci uniqueid, appmodelid
        [ValidateSet("mandatory","available")]
            #Mandatory = OfferTypeID - 0
            #Available = OfferTypeID - 2
        $type,
        #deployment settings tab
        $allowRepair, # / 0x00000008 / OfferFlags
        $predepoy, # / 0x00000001 / OfferFlags / Only required
        $closeProcesses, # / 0x00000004 / OfferFlags / Only required
        $wakeOnLan=$false, # WoLEnabled / true or false / Only required
        $allowMetered, # /  DPLocality / 0x80000 / Only required
        #end deployment settings tab
        #scheduling tab
        $asap = $false, # / simple date time to EnforcementDeadline / only mandatory
        $availableTime = $false,
        $assignmentSchedule = $false,
        $timeInUTC = $false,
        #end scheduling tab

        #user experience
        [ValidateSet("ShowAll","ShowOnlyReboot","HideAll")]
            #Mandatory = All three - HideAll will hide deployment
            #Available = ShowAll, ShowOnlyReboot
            #NotifyUser
            #UserUIExperience

            #ShowAll = NotifyUser,UserUIExperience = true
            #ShowOnlyReboot = NotifyUser = false, UserUIExperience = true
            #HideAll = NotifyUser = false, UserUIExperience = false
        $userExperience,
        $showToast = $false, #/ 0x00000020 / OfferFlags // #only for mandatory and ShowAll or HideAll user experience
        $overrideServiceWindows = $true, #OverrideServiceWindows true false
        $rebootOutsideServiceWindows = $false, #RebootOutsideOfServiceWindows true false
        $writeFilter = $true #PersistOnWriteFilterDevices true false
    )
    try {
        #see if target collection exists
        LogToCMTraceFile -message "Creating application advertisement" -type 1 -component "applicationAdvertisement"
        $targetCollectionObject = Get-WmiObject -Namespace "root\sms\site_$($Global:settingsObject.SiteName)" -ComputerName $Global:settingsObject.ServerName -Query "select collectionid,CollectionType,name from sms_collection where collectionid='$targetCollectionID'"
        if ($targetCollectionObject -eq $null) {
            #exit function
            LogToCMTraceFile -message "--- target collection id $($targetCollectionID) does not exits! Quitting function" -type 2 -component "applicationAdvertisement"
            return $false
        }
        #see if target collection is user AND mandatory deployment
        if ($targetCollectionObject.CollectionType -eq 1 -and $type -eq "mandatory") {
            LogToCMTraceFile -message "--- target collection id $($targetCollectionID) is of User type and chosen offer type is mandatory. This is not a supported combination to prevent any issues! Quitting function" -type 2 -component "applicationAdvertisement"
            LogToCMTraceFile -message "--- counting the deployment as created" -type 2 -component "applicationAdvertisement"
            return $true
        }
        #see if application is already advertised to the collection
        $ApplicationAssignmentOnCollection = Get-WmiObject -Namespace "root\sms\site_$($Global:settingsObject.SiteName)" -ComputerName $Global:settingsObject.ServerName -Query "select AssignedCI_UniqueID from SMS_ApplicationAssignment where AssignedCI_UniqueID like '$($applicationID)%' and targetcollectionid='$($targetCollectionID)'"
        if ($ApplicationAssignmentOnCollection -ne $null) {
            LogToCMTraceFile -message "--- target application $($applicationID) is already deployed! Quitting function" -type 1 -component "applicationAdvertisement"
            return $true
        }
        #find highest ci version for the application
        #get ci_id,modelid,civersion, sort it by civersion and select the last object
        #this can actually be change to a very simple query using IsLatest='true' + modelname where statements..., perhaps in the next version
        $ApplicationInfo = @(Get-WmiObject -Namespace "root\sms\site_$($Global:settingsObject.SiteName)" -ComputerName $Global:settingsObject.ServerName -Query "select LocalizedDisplayName,ci_id,modelid,civersion from sms_application where modelname='$applicationID'" | Sort CiVersion)
        if ($ApplicationInfo.Count -eq 0) {
            LogToCMTraceFile -message "--- target application model name $($applicationID) does not exits! Quitting function" -type 2 -component "applicationAdvertisement"
            return $false
        }
        
        $ApplicationInfo = $ApplicationInfo[$ApplicationInfo.Count-1]

        $highestVersion = $ApplicationInfo.CiVersion
        $uniqueCI = "$($applicationID)/$highestVersion"
        $AppCiID = $ApplicationInfo.CI_ID
        $ModelID = $ApplicationInfo.ModelID
        $AppName = $ApplicationInfo.LocalizedDisplayName

        LogToCMTraceFile -message "--- Unique CI_ID: $($uniqueCI)" -type 1 -component "applicationAdvertisement"
        LogToCMTraceFile -message "--- Application name: $($ApplicationInfo.LocalizedDisplayName)" -type 1 -component "applicationAdvertisement"
        LogToCMTraceFile -message "--- OfferType: $($type)" -type 1 -component "applicationAdvertisement"
        LogToCMTraceFile -message "--- Available time: $($availableTime)" -type 1 -component "applicationAdvertisement"
        LogToCMTraceFile -message "--- Deadline time: $($deadlineTime)" -type 1 -component "applicationAdvertisement"
        LogToCMTraceFile -message "--- As soon as possible: $($asap)" -type 1 -component "applicationAdvertisement"

        #culture info is required here if we want to get the date which is in format dd. MM. yyyy HH:mm:ss which we then change to MM. dd etc. format which is supported by WMIclass sms_advertisement for datetime. Add .000000+*** later on
        $csLocale = New-Object system.globalization.cultureinfo("cs-CS")

        $newAdvertisement = ([wmiClass]"\\$($Global:settingsObject.ServerName)\root\sms\site_$($Global:settingsObject.SiteName):SMS_ApplicationAssignment").CreateInstance()

        $newAdvertisement.AssignedCI_UniqueID = $uniqueCI
        $newAdvertisement.AppModelID = $ModelID
        $newAdvertisement.AssignedCIs = @($AppCiID)
        $newAdvertisement.AssignmentAction = 2
        $newAdvertisement.AssignmentType = 2

        $newAdvertisement.ApplicationName = $AppName

        $newAdvertisement.TargetCollectionID = $targetCollectionID
        $newAdvertisement.CollectionName = $targetCollectionObject.Name
        $newAdvertisement.SourceSite = $($Global:settingsObject.SiteName)
        $newAdvertisement.SuppressReboot = 0

        $newAdvertisement.ContainsExpiredUpdates = $false

        $newAdvertisement.CreationTime = "$(Get-Date -Format "yyyyMMddHHmmss").000000+***"

        $newAdvertisement.AssignmentName = "$($AppName)_$($targetCollectionObject.Name)"

        switch ($type) {
            "Mandatory" {
                $newAdvertisement.OfferTypeID = 0

                if ($asap -eq $false -and $assignmentSchedule -ne $false -and $availableTime -eq $false) {
                    #token is not needed for applications
                    #available time was not set for mandatory assignment - do not allow users to install it - hide notifications or show only reboot
                    $newAdvertisement.StartTime = "$(Get-Date ($(Get-Date $([DateTime]::ParseExact($assignmentSchedule,"dd. MM. yyyy HH:mm:ss",$csLocale))).AddDays(-7)) -Format "yyyyMMddHHmmss").000000+***"
                    $newAdvertisement.EnforcementDeadline = "$(Get-Date $([DateTime]::ParseExact($assignmentSchedule,"dd. MM. yyyy HH:mm:ss",$csLocale)) -Format "yyyyMMddHHmmss").000000+***"
                    #override parameter from function if it is not HideAll to make sure users are not able to install it outside the assignment schedule
                    if ($userExperience -ne "HideAll") {
                        $userExperience = "HideAll"
                    }
                } elseif ($asap -eq $false -and $assignmentSchedule -ne $false -and $availableTime -ne $false) {
                    #available time was specified - allow users to install it before the deadline
                    $newAdvertisement.StartTime = "$(Get-Date $([DateTime]::ParseExact($availableTime,"dd. MM. yyyy HH:mm:ss",$csLocale)) -Format "yyyyMMddHHmmss").000000+***"
                    $newAdvertisement.EnforcementDeadline = "$(Get-Date $([DateTime]::ParseExact($assignmentSchedule,"dd. MM. yyyy HH:mm:ss",$csLocale)) -Format "yyyyMMddHHmmss").000000+***"

                    #override parameter to make sure it is visible in software center as desired by specifying both available and mandatory times
                    $userExperience = "ShowAll"
                
                } elseif ($asap -eq $true -and $assignmentSchedule -eq $false) {
                    $newAdvertisement.StartTime = "$(Get-Date -Format "yyyyMMddHHmmss").000000+***"
                    $newAdvertisement.EnforcementDeadline = $newAdvertisement.StartTime
                }

                if ($predepoy -eq $true) { $newAdvertisement.OfferFlags = $newAdvertisement.OfferFlags -bor 0x00000001 }
                if ($closeProcesses -eq $true) { $newAdvertisement.OfferFlags = $newAdvertisement.OfferFlags -bor 0x00000004 }
                if ($allowMetered -eq $true) { $newAdvertisement.DPLocality = $newAdvertisement.DPLocality -bor 0x80000 }
                $newAdvertisement.WolEnabled = $wakeOnLan
            }

            "Available" {
                $newAdvertisement.OfferTypeID = 2

                if ($availableTime -ne $false) {
                    $newAdvertisement.StartTime = "$(Get-Date $([DateTime]::ParseExact($availableTime,"dd. MM. yyyy HH:mm:ss",$csLocale)) -Format "yyyyMMddHHmmss").000000+***"
                }
                $newAdvertisement.WolEnabled = $false
            }
        }

        if ($allowRepair -eq $true) { $newAdvertisement.OfferFlags = $newAdvertisement.OfferFlags -bor 0x00000008 }
        
        $newAdvertisement.UseGMTTimes = $timeInUTC
        
        switch ($userExperience) {
            "ShowAll" {
                $newAdvertisement.NotifyUser = $true
                $newAdvertisement.UserUIExperience = $true
            }
        
            "ShowOnlyReboot" {
                $newAdvertisement.NotifyUser = $false
                $newAdvertisement.UserUIExperience = $true
            }

            "HideAll" {
                $newAdvertisement.NotifyUser = $false
                $newAdvertisement.UserUIExperience = $false
            }
        }

        if ($showToast -eq $true -and $type -eq "Mandatory" -and ($userExperience -eq "ShowAll" -or $userExperience -eq "HideAll")) {
            $newAdvertisement.OfferFlags = $newAdvertisement.OfferFlags -bor 0x00000020
        }

        $newAdvertisement.OverrideServiceWindows = $overrideServiceWindows
        $newAdvertisement.RebootOutsideOfServiceWindows = $rebootOutsideServiceWindows
        $newAdvertisement.PersistOnWriteFilterDevices = $writeFilter
        #return $newAdvertisement
        $newAdvertisement.Put() | Out-Null
        
        LogToCMTraceFile -message "---- Successfully created the advertisement" -type 1 -component "applicationAdvertisement"
        return $true
    } catch {
        LogToCMTraceFile -message "---- Error while creating the advertisement. Error message: $($_.Exception.Message)" -type 3 -component "applicationAdvertisement"
        return $false
    }
}

Function CreatePackageAdvertisement {
    param (
        #standard properties
            $targetCollectionID,
            $packageID,
            $programName,
            [ValidateSet("mandatory","available")]
                #Mandatory = OfferType - 0
                #Available = OfferType - 2
            $type,
        #distribution points tab
            [ValidateSet("Run","Download")]
                #Run = 0x00000008 | RemoteClientFlags
                #Download = 0x00000010 | RemoteClientFlags
            $inBoundaryDP,
            [ValidateSet("Run","Download","Nothing")]
            #Run cannot be set if Download is set for InDP
                #Run = 0x00000080 | RemoteClientFlags
                #Download = 0x00000040  | RemoteClientFlags
                #Nothing = 0x00000020 | RemoteClientFlags
            $remBoundaryDP,
            $doNotFallback = $true, #0x00020000 AdvertFlags
        #------------------------
        #user experience tab
            $overrideServiceWindows = $true, #0x00100000 AdvertFlags
            $rebootOutsideServiceWindows = $false, #0x00200000 AdvertFlags
            $writeFilter = $true, #0x00008000 RemoteClientFlags
            $allowUsersToRunIndependently = $false, #0x02000000 AdvertFlags / must be set to disable
        #------------------------
        #schedules
            $asap = $false, #0x00000020 AdvertFlags
            #available time
                $availableTime = $false, #PresentTime datetime - new schedule, if this is set, make sure PresentTimeEnabled is set to true
                $availableTimeUTC = $false, #PresentTimeIsGMT
            #expiration time
                $expirationTime = $false, #ExpirationTime datetime - new schedule, if this is set, make sure ExpirationTimeEnabled is set to true
                $expirationTimeUTC = $false, #ExpirationTimeIsGMT
            #end expiration time
            $assignmentSchedule = $false,
            [ValidateSet("AlwaysRerun","NeverRerun","OnlyIfPreviousFailed","OnlyIfPreviousSucceeded")]
            $rerunBehaviour
    )
    LogToCMTraceFile -message "Creating package advertisement" -type 1 -component "packageAdvertisement"

    try {
        #see if target collection exists
        $targetCollectionObject = Get-WmiObject -Namespace "root\sms\site_$($Global:settingsObject.SiteName)" -ComputerName $Global:settingsObject.ServerName -Query "select collectionid,CollectionType from sms_collection where collectionid='$targetCollectionID'"
        if ($targetCollectionObject -eq $null) {
            #exit function
            LogToCMTraceFile -message "--- target collection id $($targetCollectionID) does not exits! Quitting function" -type 2 -component "packageAdvertisement"
            return $false
        }
        #see if target collection is user AND mandatory deployment
        if ($targetCollectionObject.CollectionType -eq 1 -and $type -eq "mandatory") {
            LogToCMTraceFile -message "--- target collection id $($targetCollectionID) is of User type and chosen offer type is mandatory. This is not a supported combination to prevent any issues! Quitting function" -type 2 -component "packageAdvertisement"
            LogToCMTraceFile -message "--- counting the deployment as created" -type 2 -component "packageAdvertisement"
            return $true
        }
        #see if package is already advertised to the collection
        $packageAdvertisementOnCollection = Get-WmiObject -Namespace "root\sms\site_$($Global:settingsObject.SiteName)" -ComputerName $Global:settingsObject.ServerName -Query "select PackageID from SMS_ADVERTISEMENT where PackageID='$($packageID)' and ProgramName='$($programName)' and collectionid='$targetCollectionID'"
        if ($packageAdvertisementOnCollection -ne $null) {
            LogToCMTraceFile -message "--- target package $($packageID):$($programName) is already deployed! Quitting function" -type 1 -component "applicationAdvertisement"
            return $true
        }
        #check if package and program exist
        $targetPackageObject = Get-WmiObject -Namespace "root\sms\site_$($Global:settingsObject.SiteName)" -ComputerName $Global:settingsObject.ServerName -Query "Select PackageID from SMS_PACKAGE where PackageID='$($packageID)'"
        if ($targetPackageObject -eq $null) {
            LogToCMTraceFile -message "--- target package id $($packageid) does not exits! Quitting function" -type 2 -component "packageAdvertisement"
            return $false
        } else {
            $targetProgramObject = Get-WmiObject -Namespace "root\sms\site_$($Global:settingsObject.SiteName)" -ComputerName $Global:settingsObject.ServerName -Query "Select ProgramName from SMS_PROGRAM where PACKAGEID='$($packageID)' and PROGRAMNAME='$($programName)'"
            if ($targetProgramObject -eq $null) {
                LogToCMTraceFile -message "--- target program name $($programName) does not exits! Quitting function" -type 2 -component "packageAdvertisement"
                return $false
            }
        } 
        #create a new advertisement
        $newAdvertisement = ([wmiClass]"\\$($Global:settingsObject.ServerName)\root\sms\site_$($Global:settingsObject.SiteName):SMS_ADVERTISEMENT").CreateInstance()
        #reset default flags
        $newAdvertisement.AdvertFlags = 0
        $newAdvertisement.RemoteClientFlags = 0

        $newAdvertisement.CollectionID = $targetCollectionID

        LogToCMTraceFile -message "--- Target CollectionID: $($targetCollectionID)" -type 1 -component "packageAdvertisement"
        LogToCMTraceFile -message "--- Package ID: $($packageID)" -type 1 -component "packageAdvertisement"
        LogToCMTraceFile -message "--- ProgramName name: $($programName)" -type 1 -component "packageAdvertisement"
        LogToCMTraceFile -message "--- OfferType: $($type)" -type 1 -component "packageAdvertisement"
        LogToCMTraceFile -message "--- Available time: $($availableTime)" -type 1 -component "packageAdvertisement"
        LogToCMTraceFile -message "--- Deadline time: $($deadlineTime)" -type 1 -component "packageAdvertisement"
        LogToCMTraceFile -message "--- As soon as possible: $($asap)" -type 1 -component "packageAdvertisement"

        #culture info is required here if we want to get the date which is in format dd. MM. yyyy HH:mm:ss which we then change to MM. dd etc. format which is supported by WMIclass sms_advertisement for datetime. Add .000000+*** later on
        $csLocale = New-Object system.globalization.cultureinfo("cs-CS")

        switch ($type) {
            "Mandatory" {
                $newAdvertisement.OfferType = 0

                if ($asap -eq $false -and $assignmentSchedule -ne $false) {
                    $newAdvertisement.AssignedScheduleEnabled = $true
                    #create a schedule token for advertisement
                    $newToken = ([wmiClass]"\\$($Global:settingsObject.ServerName)\root\sms\site_$($Global:settingsObject.SiteName):SMS_ST_NonRecurring").CreateInstance()
                    $newToken.StartTime = "$(Get-Date $([DateTime]::ParseExact($assignmentSchedule,"dd. MM. yyyy HH:mm:ss",$csLocale)) -Format "yyyyMMddHHmmss").000000+***"
                    $newAdvertisement.AssignedSchedule = $newToken
                } elseif ($asap -eq $true -and $assignmentSchedule -eq $false) {
                    $newAdvertisement.AdvertFlags = $newAdvertisement.AdvertFlags -bor 0x00000020
                }
            }

            "Available" {
                $newAdvertisement.OfferType = 2
            }
        }
    
        #add conditions
        switch ($inBoundaryDP) {
            "Run" {
                $newAdvertisement.RemoteClientFlags = $newAdvertisement.RemoteClientFlags -bor 0x00000008
            }
            "Download" {
                $newAdvertisement.RemoteClientFlags = $newAdvertisement.RemoteClientFlags -bor 0x00000010
            }
        }

        switch ($remBoundaryDP) {
            "Run" {
                $newAdvertisement.RemoteClientFlags = $newAdvertisement.RemoteClientFlags -bor 0x00000080
            }
            "Download" {
                $newAdvertisement.RemoteClientFlags = $newAdvertisement.RemoteClientFlags -bor 0x00000040
            }
            "Nothing" {
                $newAdvertisement.RemoteClientFlags = $newAdvertisement.RemoteClientFlags -bor 0x00000020
            }
        }

        if($doNotFallback -eq $true) { $newAdvertisement.AdvertFlags = $newAdvertisement.AdvertFlags -bor 0x00020000 }
        if($overrideServiceWindows -eq $true) { $newAdvertisement.AdvertFlags = $newAdvertisement.AdvertFlags -bor 0x00100000 }
        if($writeFilter -eq $true) { $newAdvertisement.RemoteClientFlags = $newAdvertisement.RemoteClientFlags -bor 0x00008000 }
    
        $newAdvertisement.PresentTimeEnabled = $true
        $newAdvertisement.PresentTimeIsGMT = $availableTimeUTC
        if ($availableTime -ne $false) {
            $newAdvertisement.PresentTime = "$(Get-Date $([DateTime]::ParseExact($availableTime,"dd. MM. yyyy HH:mm:ss",$csLocale)) -Format "yyyyMMddHHmmss").000000+***"
        } elseif ($availableTime -eq $false -and $assignmentSchedule -ne $false) {
            $newAdvertisement.PresentTime = "$(Get-Date ($(Get-Date $([DateTime]::ParseExact($assignmentSchedule,"dd. MM. yyyy HH:mm:ss",$csLocale))).AddDays(-7)) -Format "yyyyMMddHHmmss").000000+***"
        } elseif ($availableTime -eq $false -and $assignmentSchedule -eq $false -and $asap -$false) {
            $newAdvertisement.PresentTime = "$(Get-Date -Format "yyyyMMddHHmmss").000000+***"
        }

        #set this to true if available is enabled. Otherwise false if available is disabled, but set available to one week before scheduled deadline
        #$allowUsersToRunIndependently -eq $false -and 
        if($availableTime -eq $false) { 
            #setting the flag DISABLES run independently of assignments checkbox
            $newAdvertisement.AdvertFlags = $newAdvertisement.AdvertFlags -bor 0x02000000
        }

        if ($expirationTime -ne $false) {
            $newAdvertisement.ExpirationTimeEnabled = $true
            $newAdvertisement.ExpirationTime = $expirationTime
            $newAdvertisement.ExpirationTimeIsGMT = $expirationTimeUTC
        }

        switch ($rerunBehaviour) {
            "AlwaysRerun" {
                $newAdvertisement.RemoteClientFlags = $newAdvertisement.RemoteClientFlags -bor 0x00000800
            }
            "NeverRerun" {
                $newAdvertisement.RemoteClientFlags = $newAdvertisement.RemoteClientFlags -bor 0x00001000
            }
            "OnlyIfPreviousFailed" {
                $newAdvertisement.RemoteClientFlags = $newAdvertisement.RemoteClientFlags -bor 0x00002000
            }
            "OnlyIfPreviousSucceeded" {
                $newAdvertisement.RemoteClientFlags = $newAdvertisement.RemoteClientFlags -bor 0x00004000
            }
        }

        $newAdvertisement.PackageID = $packageID
        $newAdvertisement.ProgramName = $programName

        $newAdvertisement.AdvertisementName = "$($targetCollectionID)_$($packageID)_$($programName)"
        $newAdvertisement.Put() | Out-Null
        LogToCMTraceFile -message "----- Successfully created the package advertisement" -type 1 -component "packageAdvertisement"
        return $true
    } catch {
        LogToCMTraceFile -message "----- Error creating the package advertisement. Error message: $($_.Exception.Message)" -type 3 -component "packageAdvertisement"
        return $false
    }
}




#read xml file
#get number of deployments
#get number of deployments in each state (create, modify, delete) - pending separately
    #Create 
    #    pending
    #    no action
    #    check presence of collection and deployment for no action deployments. if it does not exist, log a message that it was deleted manually. Edit state for the deployment in xml file
    #Modify
    #Delete
#create all deployments that are pending create
#modify pending deployments
#delete pending deployments

LogToCMTraceFile -message "---------------------------------------------------------------------" -type 1 -component "starting"
LogToCMTraceFile -message "Date and time: $(Get-Date)" -type 1 -component "starting"
LogToCMTraceFile -message "Starting AutoScript.ps1" -type 1 -component "starting"

$Global:settingsObject = readSettingsXML
if ($Global:settingsObject -eq $false -or $Global:settingsObject -eq 1 -or ((validSettings -inputSettingsObject $Global:settingsObject) -eq $false)) {
    LogToCMTraceFile -message "- settings object is not initialized properly. Exiting with 5." -type 1 -component "starting"
    exit 5
}
LogToCMTraceFile -type 1 -component "starting" -message "Settings object is initialized to: Server name: $($Global:settingsObject.ServerName) Site name: $($Global:settingsObject.SiteName) Device collection path: $($Global:settingsObject.DeviceColPath), User collection path: $($Global:settingsObject.userColPath)"
if ($Global:settingsObject.DeviceColPath -ne "root") {
    LogToCMTraceFile -type 1 -component "starting" -message "Beginning to create SCCM folder structure for device collections"
    $Global:settingsObject.DeviceColPath = GetTargetFolderID -targetFolder $Global:settingsObject.DeviceColPath -objectType 5000
} else {
    $Global:settingsObject.DeviceColPath = 0
}

if ($Global:settingsObject.DeviceColPath -ne "root") {
    LogToCMTraceFile -type 1 -component "starting" -message "Beginning to create SCCM folder structure for device collections"
    #change path to target ID right away
    $Global:settingsObject.userColPath = GetTargetFolderID -targetFolder $Global:settingsObject.userColPath -objectType 5001
} else {
    $Global:settingsObject.userColPath
}
LogToCMTraceFile -type 1 -component "starting" -message "Target SCCM collection folder IDs"
LogToCMTraceFile -type 1 -component "starting" -message "Device collections: $($Global:settingsObject.DeviceColPath)"
LogToCMTraceFile -type 1 -component "starting" -message "User collections: $($Global:settingsObject.userColPath)"

$xmlDeploymentsFilePath = "$($PSScriptRoot)\DeploymentData\deployments.xml"
if ((Test-Path -Path $xmlDeploymentsFilePath) -eq $false) {
    LogToCMTraceFile -message "Deployments file at $($xmlDeploymentsFilePath) was not found! Exiting with 800A0035" -type 1 -component "starting"
    exit "800A0035"
}


[xml]$deploymentsFile = Get-Content -Path $xmlDeploymentsFilePath
LogToCMTraceFile -message "Loading deployments file from $($xmlDeploymentsFilePath)..." -type 1 -component "starting"
#[xml]$deploymentsFile = Get-Content -Path "C:\users\rotoloch\downloads\officeautomation\DeploymentData\deployments.xml"
LogToCMTraceFile -message "Evaluating deployments..." -type 1 -component "starting"
$allDeployments = @($deploymentsFile.Deployments.Deployment)
LogToCMTraceFile -message "--- there are $($allDeployments.Count) deployments" -type 1 -component "starting"

LogToCMTraceFile -message "----- $(@(($allDeployments | Where {$_.NextAction.Name -eq "Create"})).Count) create deployments" -type 1 -component "starting"
LogToCMTraceFile -message "----- $(@(($allDeployments | Where {$_.NextAction.Name -eq "Modify"})).Count) modify deployments" -type 1 -component "starting"
LogToCMTraceFile -message "----- $(@(($allDeployments | Where {$_.NextAction.Name -eq "Delete"})).Count) delete deployments" -type 1 -component "starting"
LogToCMTraceFile -message "----- $(@(($allDeployments | Where {$_.NextAction.Name -eq "Nothing"})).Count) no action deployments" -type 1 -component "starting"

LogToCMTraceFile -message "Processing deployments..." -type 1 -component "processing"
#addCode a condition to check deployments count
foreach ($deployment in $allDeployments) {
    #read what is needed from NextAction.Name attribute
        #create
            #collection
            #memberships
    LogToCMTraceFile -message "-- deployment $($deployment.ID), action $($deployment.NextAction.Name)" -type 1 -component "deploymentProcessing"

    switch ($deployment.NextAction.Name) {
        {($_ -eq "Create") -or ($_ -eq "Modify")} {
            $modify = $false
            if ($deployment.NextAction.Name -eq "Modify") {
                $modify = $true
            }
            #create collection DeploymentID - DeploymentName
            #identify if what type of collection we need

            #read and prepare target list ------------------------------------------------------------------------------------------------------------------------------------
            LogToCMTraceFile -message "----- reading source file $($PSScriptRoot)\DeploymentData\TargetFiles\$($deployment.ID)_Source.csv" -type 1 -component "sourceListReader"
            $sourceFile = $null
            if ((Test-Path -Path "$($PSScriptRoot)\DeploymentData\TargetFiles\$($deployment.ID)_Source.csv") -eq $false) {
                LogToCMTraceFile -message "----- source file does not exist!" -type 2 -component "sourceListReader"
            } else {
                $sourceFile = Import-Csv -Path "$($PSScriptRoot)\DeploymentData\TargetFiles\$($deployment.ID)_Source.csv" -Header Name,Type -Delimiter ";"
            }
            #$sourceFile = Import-Csv -Path "C:\users\rotoloch\downloads\officeautomation\\DeploymentData\TargetFiles\D0002_Source.csv" -Header Name,Type
            #read collection memberships first CN:IN:
            $userCollectionNeeded = $false
            $deviceCollectionNeeded = $false

            #arrays for device and user collection include and exclude rules
            #they will hold PSCUSTOMOBJECTS - NAME,RULETYPE. NAME=collection name, RULETYPE is either include or exclude
            $userCollectionsExIn = @()
            $deviceCollectionsExIn = @()

            $userAdGroups = @()
            $deviceAdGroups = @()

            $userCollectionCreatedID = $false
            $deviceCollectionCreatedID = $false
            if ($sourceFile -ne $null) {
                foreach ($entry in $sourceFile) {
                    if ($entry.Type -eq "computer") { $deviceCollectionNeeded = $true }
                    if ($entry.Type -eq "user") { $userCollectionNeeded = $true }
                    #if ($entry.Name -like "IN:*" -or $entry.Name -like "EX:*") {
                    if ($entry.Type -eq "collection") {
                        #IN: or EX:  == same length, no need to have a special condition to filter out the name
                        $fileCollectionName = $($entry.Name.Substring("IN:".Length,$entry.Name.Length-$("IN:".Length))).Trim()
                        #get the collection - to see if it even exists
                        LogToCMTraceFile -message "----- looking for collection $fileCollectionName in SCCM" -type 1 -component "sourceListReader"
                        $collectionToIncludeOrExclude = Get-WmiObject -Namespace "root\sms\site_$($Global:settingsObject.SiteName)" -ComputerName $Global:settingsObject.ServerName -Query "Select CollectionType,Name from SMS_COLLECTION where Name='$fileCollectionName'"
                        if ($collectionToIncludeOrExclude -ne $null) {
                            LogToCMTraceFile -message "------- found in SCCM" -type 1 -component "sourceListReader"
                            if ($collectionToIncludeOrExclude.CollectionType -eq 1) {
                                $ruleType = ""
                                if ($entry.Name -like "IN:*") {
                                    #if the collection is include, make sure a collection is needed
                                    LogToCMTraceFile -message "--------- include rule, adding to list" -type 1 -component "sourceListReader"
                                    $userCollectionNeeded = $true
                                    $ruleType = "Include"
                                } elseif($entry.Name -like "EX:*") {
                                    $ruleType = "Exclude"
                                    LogToCMTraceFile -message "--------- exclude rule, adding to list" -type 1 -component "sourceListReader"
                                }
                                #add the rule to needed rules for collections
                        
                                $userCollectionsExIn += [PSCustomObject]@{"Name"=$fileCollectionName;"RuleType"=$ruleType}
                            } elseif($collectionToIncludeOrExclude.CollectionType -eq 2) {
                                $ruleType = ""
                                if ($entry.Name -like "IN:*") {
                                    #if the collection is include, make sure a collection is needed
                                    LogToCMTraceFile -message "--------- include rule, adding to list" -type 1 -component "sourceListReader"
                                    $deviceCollectionNeeded = $true
                                    $ruleType = "Include"
                                } elseif($entry.Name -like "EX:*") {
                                    $ruleType = "Exclude"
                                    LogToCMTraceFile -message "--------- exclude rule, adding to list" -type 1 -component "sourceListReader"
                                }
                                $deviceCollectionsExIn += [PSCustomObject]@{"Name"=$fileCollectionName;"RuleType"=$ruleType}
                            }
                        } else {
                            #collection not found
                            LogToCMTraceFile -message "------- no such collection was found!" -type 2 -component "sourceListReader"
                        }
                    }
                }
            }
            LogToCMTraceFile -message "------- reading AdGroups" -type 1 -component "sourceListReader"
            $allAdGroups = @($deployment.AdGroups.AdGroup)
            if ($allAdGroups.Count -ne 0) {
                foreach ($adGroup in $allAdGroups) {
                    LogToCMTraceFile -message "--------- processing - $($adGroup.Name)" -type 1 -component "sourceListReader"
                    if ($adGroup -eq $null) { continue }
                    if ($adGroup.Name.Trim() -ne "" -and $adGroup.Name.Length -ge 4) {
                        if ($adGroup.Name -like "UC:*") {
                            LogToCMTraceFile -message "----------- user AD" -type 1 -component "sourceListReader"
                            $userAdGroups += $adGroup.Name.SubString(3,$adGroup.Name.Length-3)
                            $userCollectionNeeded = $true
                        } elseif ($adGroup.Name -like "DC:*") {
                            LogToCMTraceFile -message "----------- computer AD" -type 1 -component "sourceListReader"
                            $deviceAdGroups += $adGroup.Name.SubString(3,$adGroup.Name.Length-3)
                            $deviceCollectionNeeded = $true
                        } else {
                            LogToCMTraceFile -message "----------- ad group name is invalid - $($adGroup.Name)" -type 2 -component "sourceListReader"
                        }
                    } else {
                        LogToCMTraceFile -message "----------- ad group name is invalid - $($adGroup.Name)" -type 2 -component "sourceListReader"
                    }
                }
            } else {
                LogToCMTraceFile -message "------- no ad groups found for the deployment" -type 1 -component "sourceListReader"
            }

            LogToCMTraceFile -message "----- user collection is needed: $userCollectionNeeded" -type 1 -component "sourceListReader"
            LogToCMTraceFile -message "----- device collection is needed: $deviceCollectionNeeded" -type 1 -component "sourceListReader"
            #end read and prepare target list  ------------------------------------------------------------------------------------------------------------------------------------


            #create a query in statement for collections that are already created for the deployment for later usage ------------------------------------------------------------------------------------------------------------------------------------
            
            $colQuery = ""
            if ($modify -eq $true) {
                LogToCMTraceFile -message "----- preparing query IN statement for collections that are already created" -type 1 -component "sourceListReader"
                $alreadyCreatedCollections = ($deployment.SCCMInformation.ColID).Split(",")
                if ($alreadyCreatedCollections.Count -ge 1) {
                    $colQuery = ""
                    foreach ($it in $alreadyCreatedCollections) {
                        $colQuery += "'$($it)',"
                    }
                    $colQuery = $colQuery.Substring(0,$colQuery.Length -1)
                }
                LogToCMTraceFile -message "------- result: $colQuery" -type 1 -component "sourceListReader"
            }
            if ($colQuery -eq "''") {$colQuery = ""}
            #end query in statement 

            #variable for XML SCCMInformation ColID tag
            $createdCollections = ""
            
            #user collection actions - if col is needed, create it, save its id, create all rules. 
                #if modify is selected, try to find respective collection for users and if it is no longer needed, remove it
                #otherwise remove all rules and recreate them again
            $idOfCreatedCollection = $false
            
            if ($userCollectionNeeded -eq $true) {
                LogToCMTraceFile -message "------ USER COLLECTION STEPS" -type 1 -component "collectionCreator"
                #create or find the collection - save the result to idofcreatedcollection variable which is then sent to the function which creates memberships
                if ($modify -eq $false) {
                    $idOfCreatedCollection = createCollection -collectionName "$($deployment.ID) - $($deployment.Name)" -collectionType 1 -collectionComment $deployment.CreatedBy.Reason
                    LogToCMTraceFile -message "------- collectionid: $idOfCreatedCollection" -type 1 -component "collectionCreator"
                } else {
                    #get user collection that is already in place - do not create a new one, if no user collection is found, create a new one
                    if ($colQuery -ne "") {
                        LogToCMTraceFile -message "----- looking for collections using the IN statement" -type 1 -component "collectionCreator"
                        $idOfCreatedCollection = (Get-WmiObject -Namespace "root\sms\site_$($Global:settingsObject.SiteName)" -ComputerName $Global:settingsObject.ServerName -Query "Select CollectionId from SMS_COLLECTION where CollectionId in ($colQuery) and CollectionType='1'").CollectionId
                        if ($idOfCreatedCollection -eq $null) {
                            LogToCMTraceFile -message "----- no user collection was found - creating" -type 1 -component "collectionCreator"
                            $idOfCreatedCollection = createCollection -collectionName "$($deployment.ID) - $($deployment.Name)" -collectionType 1 -collectionComment $deployment.CreatedBy.Reason
                            LogToCMTraceFile -message "------- collectionid: $idOfCreatedCollection" -type 1 -component "collectionCreator"
                        } else {
                            LogToCMTraceFile -message "----- collection found, collectionid: $idOfCreatedCollection" -type 1 -component "collectionCreator"
                            
                            LogToCMTraceFile -message "------- removing all collection rules and renaming (if needed)" -type 1 -component "collectionCreator"
                            try {
                                $fullcollectionObject = [wmi](Get-WmiObject -Namespace "root\sms\site_$($Global:settingsObject.SiteName)" -ComputerName $Global:settingsObject.ServerName -Query "select * from sms_collection where collectionid='$($idOfCreatedCollection)'").__PATH
                                $fullcollectionObject.CollectionRules = @()
                                if ($fullcollectionObject.Name -ne "UC $($deployment.ID) - $($deployment.Name)") {
                                    $fullcollectionObject.Name = "UC $($deployment.ID) - $($deployment.Name)"
                                }
                                $fullcollectionObject.Put() | Out-Null
                                $fullcollectionObject = $null
                            } catch {
                                LogToCMTraceFile -message "------- error removing collection rules $($_.Exception.Message)" -type 3 -component "collectionCreator"
                            }
                        }
                    } else {
                        LogToCMTraceFile -message "----- built IN statement was null" -type 1 -component "collectionCreator"
                        $idOfCreatedCollection = createCollection -collectionName "$($deployment.ID) - $($deployment.Name)" -collectionType 1 -collectionComment $deployment.CreatedBy.Reason
                        LogToCMTraceFile -message "------- collectionid: $idOfCreatedCollection" -type 1 -component "collectionCreator"
                    }
                }
                #createCollection function returns false if it fails, create a condition that executes steps only if it did not fail
                if ($idOfCreatedCollection -ne $false) {
                    $createdCollections = $idOfCreatedCollection
                    $userCollectionCreatedID = $idOfCreatedCollection

                    if ($Global:settingsObject.UserColPath -ne 0) {
                        LogToCMTraceFile -message "--------- moving the collection to target folder id $($Global:settingsObject.UserColPath)" -type 1 -component "collectionMove"
                        $moveResult = MoveSCCMItem -objectID $userCollectionCreatedID -parentFolderID 0 -targetFolderID $Global:settingsObject.UserColPath -objectType 5001
                        if ($moveResult -eq $true) {
                            LogToCMTraceFile -message "--------- moving was successful" -type 1 -component "collectionMove"
                        } else {
                            LogToCMTraceFile -message "--------- error while moving the collection" -type 3 -component "collectionMove"
                        }
                    } else {
                        LogToCMTraceFile -message "------no need to move the collection. Target is ROOT" -type 1 -component "collectionMove"
                    }
                    
                    LogToCMTraceFile -message "--------- creating membership rules" -type 1 -component "membershipCreator"
                    #create memberships - first for users and then collections
                    $allUserCollectionRules = @()
                    foreach ($entry in ($sourceFile | Where {$_.Type -eq "User"})) {
                        $colRule = createCollectionMembership -collectionID $idOfCreatedCollection -ruleType "directUser" -ruleName $entry.Name
                        if ($colRule -ne $false) {
                            $allUserCollectionRules += $colRule
                        }
                    }
                    foreach ($col in $userCollectionsExIn) {
                        #ruletype is either include or exclude - no need for conditions
                        #if ($col.RuleType -eq "Include") {
                        $colRule = createCollectionMembership -collectionID $idOfCreatedCollection -ruleType "$($col.RuleType)UserCol" -ruleName $col.Name
                        if ($colRule -ne $false) {
                            $allUserCollectionRules += $colRule
                        }
                        #} elseif ($col.RuleType -eq "Exclude") {
                        #    createCollectionMembership -collectionID $idOfCreatedCollection -ruleType "exclude" -ruleName $col.Name
                        #}
                    }
                    foreach ($userAdGroup in $userAdGroups) {
                        $colRule = createCollectionMembership -collectionID $idOfCreatedCollection -ruleType "queryUser" -ruleName $userAdGroup
                        if ($colRule -ne $false) {
                            $allUserCollectionRules += $colRule
                        }
                    }
                    LogToCMTraceFile -message "--------- finished creating rules, applying" -type 1 -component "membershipCreator"
                    if ($allUserCollectionRules.Count -ge 1) {
                        try {
                            $collectionObject = [wmi](Get-WmiObject -Namespace "root\sms\site_$($Global:settingsObject.SiteName)" -ComputerName $Global:settingsObject.ServerName -Query "Select * from SMS_COLLECTION where CollectionId='$idOfCreatedCollection'").__PATH
                            if ($collectionObject -ne $null) {
                                $collectionObject.CollectionRules = $allUserCollectionRules
                                $collectionObject.Put() | Out-Null
                            } else {
                                LogToCMTraceFile -message "----------- error updating collection rules. Could not retrieve the newly created collection!" -type 3 -component "membershipCreator"
                            }
                        } catch {
                            LogToCMTraceFile -message "----------- error updating collection rules. Error message: $($_.Exception.Message)" -type 3 -component "membershipCreator"
                        }
                    } else {
                        LogToCMTraceFile -message "--------- no rules were created, attempting to remove the created collection" -type 2 -component "membershipCreator"
                        try {
                            $collectionObject = Get-WmiObject -Namespace "root\sms\site_$($Global:settingsObject.SiteName)" -ComputerName $Global:settingsObject.ServerName -Query "Select * from SMS_COLLECTION where CollectionId='$idOfCreatedCollection'"
                            if ($collectionObject -ne $null) {
                                $collectionObject | Remove-WmiObject
                                $userCollectionCreatedID = $false
                            } else {
                                LogToCMTraceFile -message "----------- error removing the collection. The object could not be retrieved from WMI." -type 3 -component "membershipCreator"
                            }
                        } catch {
                            LogToCMTraceFile -message "----------- error removing the collection. Error message: $($_.Exception.Message)" -type 3 -component "membershipCreator"
                        }
                    }
                }
            } elseif ($userCollectionNeeded -eq $false -and $modify -eq $true) {
                #if no collection is needed and modify is selected, check if collection exists, if so, remove it
                LogToCMTraceFile -message "--------- user collection is no longer needed, attempting to remove" -type 1 -component "collectionRemoval"
                if ($colQuery -ne "") {
                    $colToRemoveId = (Get-WmiObject -Namespace "root\sms\site_$($Global:settingsObject.SiteName)" -ComputerName $Global:settingsObject.ServerName -Query "Select CollectionId from SMS_COLLECTION where CollectionId in ($colQuery) and CollectionType='1'").CollectionId
                    if ($colToRemoveId -ne $null) {
                        $colToRemove = Get-WmiObject -Namespace "root\sms\site_$($Global:settingsObject.SiteName)" -ComputerName $Global:settingsObject.ServerName -Query "select * from sms_collection where collectionid='$colToRemoveId'"
                        LogToCMTraceFile -message "--------- removing $($colToRemove.CollectionID)" -type 1 -component "collectionRemoval"
                        try { 
                            $colToRemove | Remove-WmiObject
                            $userCollectionCreatedID = $false
                        } catch {
                            LogToCMTraceFile -message "----------- error removing the collection. Error message: $($_.Exception.Message)" -type 3 -component "collectionRemoval"
                        }
                    } else {
                        LogToCMTraceFile -message "--------- no collection found" -type 1 -component "collectionRemoval"
                    }
                } else {
                    LogToCMTraceFile -message "--------- no collection found" -type 1 -component "collectionRemoval"
                }
            } 
            #end user collection actions ------------------------------------------------------------------------------------------------------------------------------------


            #device collection actions - absolutely same logic as for user collection ------------------------------------------------------------------------------------------------------------------------------------
            $idOfCreatedCollection = $false
            if ($deviceCollectionNeeded -eq $true) {
                LogToCMTraceFile -message "------ DEVICE COLLECTION STEPS" -type 1 -component "collectionCreator"
                if ($modify -eq $false) {
                    $idOfCreatedCollection = createCollection -collectionName "$($deployment.ID) - $($deployment.Name)" -collectionType 2 -collectionComment $deployment.CreatedBy.Reason
                    LogToCMTraceFile -message "------- collectionid: $idOfCreatedCollection" -type 1 -component "collectionCreator"
                } else {
                    #get device collection that is already in place - do not create a new one, if no device collection is found, create a new one
                    if ($colQuery -ne "") {
                        LogToCMTraceFile -message "----- looking for collections using the IN statement" -type 1 -component "collectionCreator"
                        $idOfCreatedCollection = (Get-WmiObject -Namespace "root\sms\site_$($Global:settingsObject.SiteName)" -ComputerName $Global:settingsObject.ServerName -Query "Select CollectionId from SMS_COLLECTION where CollectionId in ($colQuery) and CollectionType='2'").CollectionId
                        if ($idOfCreatedCollection -eq $null) {
                            LogToCMTraceFile -message "----- no device collection was found - creating" -type 1 -component "collectionCreator"
                            $idOfCreatedCollection = createCollection -collectionName "$($deployment.ID) - $($deployment.Name)" -collectionType 2 -collectionComment $deployment.CreatedBy.Reason
                            LogToCMTraceFile -message "------- collectionid: $idOfCreatedCollection" -type 1 -component "collectionCreator"
                        } else {
                            LogToCMTraceFile -message "----- collection found, collectionid: $idOfCreatedCollection" -type 1 -component "collectionCreator"
                            LogToCMTraceFile -message "------- removing all collection rules" -type 1 -component "collectionCreator"
                            #remove all memberships
                            try {
                                $fullcollectionObject = [wmi](Get-WmiObject -Namespace "root\sms\site_$($Global:settingsObject.SiteName)" -ComputerName $Global:settingsObject.ServerName -Query "select * from sms_collection where collectionid='$($idOfCreatedCollection)'").__PATH
                                $fullcollectionObject.CollectionRules = @()
                                if ($fullcollectionObject.Name -ne "DC $($deployment.ID) - $($deployment.Name)") {
                                    $fullcollectionObject.Name = "DC $($deployment.ID) - $($deployment.Name)"
                                }
                                $fullcollectionObject.Put() | Out-Null
                                $fullcollectionObject = $null
                            } catch {
                                LogToCMTraceFile -message "------- error removing collection rules $($_.Exception.Message)" -type 3 -component "collectionCreator"
                            }
                        }
                    } else {
                        LogToCMTraceFile -message "----- built IN statement was null" -type 1 -component "collectionCreator"
                        $idOfCreatedCollection = createCollection -collectionName "$($deployment.ID) - $($deployment.Name)" -collectionType 2 -collectionComment $deployment.CreatedBy.Reason
                        LogToCMTraceFile -message "------- collectionid: $idOfCreatedCollection" -type 1 -component "collectionCreator"
                    }
                    
                }
                if ($idOfCreatedCollection -ne $false) {
                    if ($createdCollections -ne "") {
                        $createdCollections += ",$($idOfCreatedCollection)"
                    } else {
                        $createdCollections = "$($idOfCreatedCollection)"
                    }
                    $deviceCollectionCreatedID = $idOfCreatedCollection

                    if ($Global:settingsObject.DeviceColPath -ne 0) {
                        LogToCMTraceFile -message "--------- moving the collection to target folder id $($Global:settingsObject.DeviceColPath)" -type 1 -component "collectionMove"
                        $moveResult = MoveSCCMItem -objectID $deviceCollectionCreatedID -parentFolderID 0 -targetFolderID $Global:settingsObject.DeviceColPath -objectType 5000
                        if ($moveResult -eq $true) {
                            LogToCMTraceFile -message "--------- moving was successful" -type 1 -component "collectionMove"
                        } else {
                            LogToCMTraceFile -message "--------- error while moving the collection" -type 3 -component "collectionMove"
                        }
                    } else {
                        LogToCMTraceFile -message "------no need to move the collection. Target is ROOT" -type 1 -component "collectionMove"
                    }

                    LogToCMTraceFile -message "--------- creating membership rules" -type 1 -component "membershipCreator"
                    $allDeviceCollectionRules = @()
                    foreach ($entry in ($sourceFile | Where {$_.Type -eq "Computer"})) {
                        $colRule = createCollectionMembership -collectionID $idOfCreatedCollection -ruleType "directComputer" -ruleName $entry.Name
                        if ($colRule -ne $false) {
                            $allDeviceCollectionRules += $colRule
                        }
                    }
                    foreach ($col in $deviceCollectionsExIn) {
                        #ruletype is either include or exclude - no need for conditions
                        #if ($col.RuleType -eq "Include") {
                            $colRule = createCollectionMembership -collectionID $idOfCreatedCollection -ruleType "$($col.RuleType)DeviceCol" -ruleName $col.Name
                            if ($colRule -ne $false) {
                                $allDeviceCollectionRules += $colRule
                            }
                        #} elseif ($col.RuleType -eq "Exclude") {
                        #    createCollectionMembership -collectionID $idOfCreatedCollection -ruleType "exclude" -ruleName $col.Name
                        #}
                    }
                    foreach ($deviceAdGroup in $deviceAdGroups) {
                        $colRule = createCollectionMembership -collectionID $idOfCreatedCollection -ruleType "queryDevice" -ruleName $deviceAdGroup
                        if ($colRule -ne $false) {
                            $allDeviceCollectionRules += $colRule
                        }
                    }
                    LogToCMTraceFile -message "--------- finished creating rules, applying" -type 1 -component "membershipCreator"
                    if ($allDeviceCollectionRules.Count -ge 1) {
                        try {
                            $collectionObject = [wmi](Get-WmiObject -Namespace "root\sms\site_$($Global:settingsObject.SiteName)" -ComputerName $Global:settingsObject.ServerName -Query "Select * from SMS_COLLECTION where CollectionId='$idOfCreatedCollection'").__PATH
                            if ($collectionObject -ne $null) {
                                $collectionObject.CollectionRules = $allDeviceCollectionRules
                                $collectionObject.Put() | Out-Null
                            } else {
                                LogToCMTraceFile -message "----------- error updating collection rules. Could not retrieve the newly created collection!" -type 3 -component "membershipCreator"
                            }
                        } catch {
                            LogToCMTraceFile -message "----------- error updating collection rules. Error message: $($_.Exception.Message)" -type 3 -component "membershipCreator"
                        }
                    } else {
                        LogToCMTraceFile -message "--------- no rules were created, attempting to remove the created collection" -type 2 -component "membershipCreator"
                        try {
                            $collectionObject = Get-WmiObject -Namespace "root\sms\site_$($Global:settingsObject.SiteName)" -ComputerName $Global:settingsObject.ServerName -Query "Select * from SMS_COLLECTION where CollectionId='$idOfCreatedCollection'"
                            if ($collectionObject -ne $null) {
                                $collectionObject | Remove-WmiObject
                                $deviceCollectionCreatedID = $false
                            } else {
                                LogToCMTraceFile -message "----------- error removing the collection. The object could not be retrieved from WMI." -type 3 -component "membershipCreator"
                            }
                        } catch {
                            LogToCMTraceFile -message "----------- error removing the collection. Error message: $($_.Exception.Message)" -type 3 -component "membershipCreator"
                        }
                    }
                    
                }
            } elseif ($deviceCollectionNeeded -eq $false -and $modify -eq $true) {
                #if no collection is needed and modify is selected, check if collection exists, if so, remove it
                LogToCMTraceFile -message "--------- device collection is no longer needed, attempting to remove" -type 1 -component "collectionRemoval"
                if ($colQuery -ne "") {
                    $colToRemoveId = (Get-WmiObject -Namespace "root\sms\site_$($Global:settingsObject.SiteName)" -ComputerName $Global:settingsObject.ServerName -Query "Select CollectionId from SMS_COLLECTION where CollectionId in ($colQuery) and CollectionType='2'").CollectionId
                    if ($colToRemoveId -ne $null) {
                        $colToRemove = Get-WmiObject -Namespace "root\sms\site_$($Global:settingsObject.SiteName)" -ComputerName $Global:settingsObject.ServerName -Query "select * from sms_collection where collectionid='$colToRemoveId'"
                        LogToCMTraceFile -message "--------- removing $($colToRemove.CollectionID)" -type 1 -component "collectionRemoval"
                        try { 
                            $colToRemove | Remove-WmiObject
                            $deviceCollectionCreatedID = $false
                        } catch {
                            LogToCMTraceFile -message "----------- error removing the collection. Error message: $($_.Exception.Message)" -type 3 -component "collectionRemoval"
                        }
                    } else {
                        LogToCMTraceFile -message "--------- no collection found" -type 1 -component "collectionRemoval"
                    }
                } else {
                    LogToCMTraceFile -message "--------- no collection found" -type 1 -component "collectionRemoval"
                }
            }
            #end device collection actions ------------------------------------------------------------------------------------------------------------------------------------
            
            #check if any collection was created
            LogToCMTraceFile -message "Beginning to create or remove advertisements" -type 1 -component "advCreator"
            if ($userCollectionCreatedID -ne $false -or $deviceCollectionCreatedID -ne $false) {
                #if userCol does not equal false OR devCol does not equal false, continue
                LogToCMTraceFile -message "--- reading objects to deploy" -type 1 -component "advCreator"
                $objectsToDeploy = @($deployment.ObjectsToDeploy.ObjectToDeploy)
                if ($objectsToDeploy.Count -ne 0) {
                    LogToCMTraceFile -message "--- found $($objectsToDeploy.Count) objects to deploy" -type 1 -component "advCreator"
                    #create deployments to collection(s)
                    #read available and deadline times
                    $availableTime = $deployment.AvailableTime.DateTime
                    if ($availableTime -eq "notset") {$availableTime = $false}
                    $deadlineTime = $deployment.Deadlinetime.DateTime
                    if ($deadlineTime -eq "notset") { 
                        $deadlineTime = $false
                        $offerType = "available"
                    } else {
                        $offerType = "mandatory"
                    }
                    LogToCMTraceFile -message "--- new advertisement settings (Already existing advertisements that are still being deployed will not be changed!)" -type 1 -component "advCreator"
                    LogToCMTraceFile -message "----- offer type $($offerType)" -type 1 -component "advCreator"
                    LogToCMTraceFile -message "----- available time $($availableTime)" -type 1 -component "advCreator"
                    LogToCMTraceFile -message "----- deadline time $($deadlineTime)" -type 1 -component "advCreator"
                    
                    if ($deployment.NextAction.Name -eq "Modify") {
                        LogToCMTraceFile -message "--- reading existing deployments. Script will remove advertisements that do not belong to the deployment anymore." -type 1 -component "advCreator"
                        #see if there are any deployments that should be deleted. Collections that are not needed anymore are already removed at this point
                        if ($userCollectionCreatedID -ne $false) {
                            $allPackageUserAdvs = @(Get-WmiObject -Namespace "root\sms\site_$($Global:settingsObject.SiteName)" -ComputerName $Global:settingsObject.ServerName -Query "select * from sms_advertisement where CollectionID='$userCollectionCreatedID'")
                            LogToCMTraceFile -message "----- found $($allPackageUserAdvs.Count) package advertisements to user collection $($userCollectionCreatedID)" -type 1 -component "advCreator"
                            foreach ($adv in $allPackageUserAdvs) {
                                #compare with objectstodeploy, if it is not there, remove it
                                #attempt to select child from objectstodeploy that equals currently iterated advertisement
                                $toDeploy = $objectsToDeploy | Where {$_.ObjectID -eq $adv.PackageID -and $_.ProgramName -eq $adv.ProgramName}
                                #if toDeploy = $Null, remove advertisement as it is not part of this deployment anymore
                                if ($toDeploy -eq $null) {
                                    LogToCMTraceFile -message "----- advertisement of package $($adv.PackageID):$($adv.ProgramName) needs to be deleted. Deleting..." -type 1 -component "advCreator"
                                    try {
                                        $adv | Remove-WmiObject
                                        LogToCMTraceFile -message "------- successfully removed" -type 1 -component "advCreator"
                                    } catch {
                                        LogToCMTraceFile -message "------- error removing the advertisement. Error message: $($_.Exception.Message)" -type 3 -component "advCreator"
                                    }
                                }
                            }
                            #do the same for applications
                            $allApplicationUserAdvs = @(Get-WmiObject -Namespace "root\sms\site_$($Global:settingsObject.SiteName)" -ComputerName $Global:settingsObject.ServerName -Query "select * from SMS_ApplicationAssignment where TargetCollectionID='$userCollectionCreatedID'")
                            LogToCMTraceFile -message "----- found $($allApplicationUserAdvs.Count) application advertisements to user collection $($userCollectionCreatedID)" -type 1 -component "advCreator"
                            foreach ($adv in $allApplicationUserAdvs) {
                                $toDeploy = $objectsToDeploy | Where {$($adv.AssignedCI_UniqueID) -like "$($_.ObjectID)*"}
                                if ($toDeploy -eq $null) {
                                    LogToCMTraceFile -message "----- advertisement of application $($adv.AssignedCI_UniqueID) needs to be deleted. Deleting..." -type 1 -component "advCreator"
                                    try {
                                        $adv | Remove-WmiObject
                                        LogToCMTraceFile -message "------- successfully removed" -type 1 -component "advCreator"
                                    } catch {
                                        LogToCMTraceFile -message "------- error removing the advertisement. Error message: $($_.Exception.Message)" -type 3 -component "advCreator"
                                    }
                                }
                            }
                        }
                        if ($deviceCollectionCreatedID -ne $false) {
                            $allPackageDevAdvs = @(Get-WmiObject -Namespace "root\sms\site_$($Global:settingsObject.SiteName)" -ComputerName $Global:settingsObject.ServerName -Query "select * from sms_advertisement where CollectionID='$deviceCollectionCreatedID'")
                            LogToCMTraceFile -message "----- found $($allPackageDevAdvs.Count) package advertisements to device collection $($deviceCollectionCreatedID)" -type 1 -component "advCreator"
                            foreach ($adv in $allPackageDevAdvs) {
                                #compare with objectstodeploy, if it is not there, remove it
                                #attempt to select child from objectstodeploy that equals currently iterated advertisement
                                $toDeploy = $objectsToDeploy | Where {$_.ObjectID -eq $adv.PackageID -and $_.ProgramName -eq $adv.ProgramName}
                                #if toDeploy = $Null, remove advertisement as it is not part of this deployment anymore
                                if ($toDeploy -eq $null) {
                                    LogToCMTraceFile -message "----- advertisement of package $($adv.PackageID):$($adv.ProgramName) needs to be deleted. Deleting..." -type 1 -component "advCreator"
                                    try {
                                        $adv | Remove-WmiObject
                                        LogToCMTraceFile -message "------- successfully removed" -type 1 -component "advCreator"
                                    } catch {
                                        LogToCMTraceFile -message "------- error removing the advertisement. Error message: $($_.Exception.Message)" -type 3 -component "advCreator"
                                    }
                                }
                            }
                            $allApplicationDevAdvs = @(Get-WmiObject -Namespace "root\sms\site_$($Global:settingsObject.SiteName)" -ComputerName $Global:settingsObject.ServerName -Query "select * from SMS_ApplicationAssignment where TargetCollectionID='$deviceCollectionCreatedID'")
                            LogToCMTraceFile -message "----- found $($allApplicationDevAdvs.Count) application advertisements to device collection $($deviceCollectionCreatedID)" -type 1 -component "advCreator"
                            foreach ($adv in $allApplicationDevAdvs) {
                                $toDeploy = $objectsToDeploy | Where {$($adv.AssignedCI_UniqueID) -like "$($_.ObjectID)*"}
                                if ($toDeploy -eq $null) {
                                    LogToCMTraceFile -message "----- advertisement of application $($adv.AssignedCI_UniqueID) needs to be deleted. Deleting..." -type 1 -component "advCreator"
                                    try {
                                        $adv | Remove-WmiObject
                                        LogToCMTraceFile -message "------- successfully removed" -type 1 -component "advCreator"
                                    } catch {
                                        LogToCMTraceFile -message "------- error removing the advertisement. Error message: $($_.Exception.Message)" -type 3 -component "advCreator"
                                    }
                                }
                            }
                        }
                    }

                    $createdAdvs = 0
                    $neededAdvs = $objectsToDeploy.Count*($createdCollections.Split(",").Count)
                    foreach ($objectToDeploy in $objectsToDeploy) {
                    #userCollection
                        $advCreated = $false
                        if ($objectToDeploy.ObjectID -like "Scope*") {
                            #applications    
                            if ($userCollectionCreatedID -ne $false) {
                                $advCreated = CreateApplicationAdvertisement -targetCollectionID $userCollectionCreatedID -applicationID $objectToDeploy.ObjectID -type $offerType -availableTime $availableTime -assignmentSchedule $deadlineTime -userExperience ShowAll
                                if ($advCreated -eq $true) {$createdAdvs++}
                            }
                            if ($deviceCollectionCreatedID -ne $false) {
                                $advCreated = CreateApplicationAdvertisement -targetCollectionID $deviceCollectionCreatedID -applicationID $objectToDeploy.ObjectID -type $offerType -availableTime $availableTime -assignmentSchedule $deadlineTime -userExperience ShowAll
                                if ($advCreated -eq $true) {$createdAdvs++}
                            }
                        } else {
                            #packages    
                            if ($userCollectionCreatedID -ne $false) {
                                $advCreated = CreatePackageAdvertisement -targetCollectionID $userCollectionCreatedID -packageID $objectToDeploy.ObjectID -type $offerType -programName $objectToDeploy.ProgramName -availableTime $availableTime -assignmentSchedule $deadlineTime -inBoundaryDP Download -remBoundaryDP Download
                                if ($advCreated -eq $true) {$createdAdvs++}
                            }
                            if ($deviceCollectionCreatedID -ne $false) {
                                $advCreated = CreatePackageAdvertisement -targetCollectionID $deviceCollectionCreatedID -packageID $objectToDeploy.ObjectID -type $offerType -programName $objectToDeploy.ProgramName -availableTime $availableTime -assignmentSchedule $deadlineTime -inBoundaryDP Download -remBoundaryDP Download
                                if ($advCreated -eq $true) {$createdAdvs++}
                            }

                        }
                    }
                    if ($createdAdvs -ne 0 -and $createdAdvs -eq $neededAdvs) {
                        $deployment.SCCMInformation.Status = "Success-0"
                        LogToCMTraceFile -message "----- number of created advertisements $($createdAdvs), needed $($neededAdvs)" -type 1 -component "advCreator"
                    } else {
                        #no advs created
                        $deployment.SCCMInformation.Status = "Warning-5"
                        LogToCMTraceFile -message "----- number of created advertisements $($createdAdvs), needed $($neededAdvs)" -type 2 -component "advCreator"
                    }
                } else {
                    #no objects to deploy
                    LogToCMTraceFile -message "----- no objects to deploy were found!" -type 2 -component "advCreator"
                    $deployment.SCCMInformation.Status = "Warning-6"
                }
                
            } else {
                #no collections were created
                LogToCMTraceFile -message "----- no collections were created!" -type 2 -component "advCreator"
                $deployment.SCCMInformation.Status = "Warning-7"
            }
            $deployment.NextAction.Name = "Nothing"
            $deployment.SCCMInformation.ColID = $createdCollections
            $deployment.SCCMInformation.ColName = "$($deployment.ID) - $($deployment.Name)"
            LogToCMTraceFile -message "----- modifying deployment in XML file." -type 1 -component "advCreator"
            LogToCMTraceFile -message "---- COMPLETED ACTIONS FOR deployment $($deployment.ID), action create or modify" -type 1 -component "deploymentRemoval"
        }

        "Delete" {
            LogToCMTraceFile -message "---- reading created collections" -type 1 -component "deploymentRemoval"
            $createdCollections = $deployment.SCCMInformation.ColID.Split(",")
            LogToCMTraceFile -message "------ there are $($createdCollections.Count) collection(s) to remove" -type 1 -component "deploymentRemoval"
            $success = $false
            foreach ($collection in $createdCollections) {
                $success = removeCollection -collectionID $collection
            }
            LogToCMTraceFile -message "---- removing collections was successful: $($success)" -type 1 -component "deploymentRemoval"
            LogToCMTraceFile -message "---- modifying XML for the deployment" -type 1 -component "deploymentRemoval"
            if ($success -eq $true) {
                $deployment.SCCMInformation.ColID = ""
                $deployment.SCCMInformation.ColName = ""
                $deployment.SCCMInformation.Status = "Removed"
                $deployment.NextAction.Name = "Nothing"
            } else {
                $deployment.SCCMInformation.Status = "Error removing collections"
                $deployment.NextAction.Name = "Nothing"
            }
            LogToCMTraceFile -message "---- COMPLETED ACTIONS FOR deployment $($deployment.ID), action delete" -type 1 -component "deploymentRemoval"
        }
        "Nothing" {
            if ($deployment.SCCMInformation.Status -eq "Removed") {
                LogToCMTraceFile -message "---- skipping the deployment because it should be removed already" -type 1 -component "deploymentChecker"
                continue
            }
            LogToCMTraceFile -message "---- reading created collections" -type 1 -component "deploymentChecker"
            if ($deployment.SCCMInformation.ColID -eq "") {
                LogToCMTraceFile -message "------ there are no collections in XML for this deployment!" -type 2 -component "deploymentChecker"
                $deployment.SCCMInformation.Status = "Warning-7"
                continue
            }
            $createdCollections = $deployment.SCCMInformation.ColID.Split(",")
            LogToCMTraceFile -message "------ there are $($createdCollections.Count) collection(s) that should exist. Beginning to check collections' presence." -type 1 -component "deploymentChecker"
            $modifiedOutsideScript = $false
            $mandatoryDeployment = $deployment.Deadlinetime.DateTime
            if ($mandatoryDeployment -ne "notset") {
                LogToCMTraceFile -message "------ current advertisement settings is mandatory" -type 1 -component "deploymentChecker"
                LogToCMTraceFile -message "------ user collection targeted advertisements will be counted as created even if they do not exist" -type 1 -component "deploymentChecker"
                $mandatoryDeployment = $true
            } else {
                LogToCMTraceFile -message "------ current advertisement settings is available" -type 1 -component "deploymentChecker"
                $mandatoryDeployment = $false
            }
            foreach ($collection in $createdCollections) {
                LogToCMTraceFile -message "---- looking for $($collection)" -type 1 -component "deploymentChecker"
                try {
                    $collectionObject = Get-WmiObject -Namespace "root\sms\site_$($Global:settingsObject.SiteName)" -ComputerName $Global:settingsObject.ServerName -Query "select CollectionID,CollectionType from sms_collection where collectionid='$($collection)'"
                } catch {
                    LogToCMTraceFile -message "------ error retrieving collection object from SCCM. Error message: $($_.Exception.Message)" -type 3 -component "deploymentChecker"
                    continue
                }
                if ($collectionObject -eq $null) {
                    LogToCMTraceFile -message "------ collection does not exist!" -type 2 -component "deploymentChecker"
                    $modifiedOutsideScript = $true
                } else {
                    LogToCMTraceFile -message "------ collection was retrieved from SCCM. Beginning to check advertisements" -type 1 -component "deploymentChecker"
                    try {
                        $allPackageAdvertisements = Get-WmiObject -Namespace "root\sms\site_$($Global:settingsObject.SiteName)" -ComputerName $Global:settingsObject.ServerName -Query "Select packageID,ProgramName,offertype from SMS_Advertisement where CollectionID='$collection'"
                        $allApplicationAdvertisements = Get-WmiObject -Namespace "root\sms\site_$($Global:settingsObject.SiteName)" -ComputerName $Global:settingsObject.ServerName -Query "Select AssignedCI_UniqueID,offertypeid from SMS_ApplicationAssignment where targetCollectionID='$collection'"
                    } catch {
                        LogToCMTraceFile -message "------ error retrieving advertisement for collection from SCCM. Error message: $($_.Exception.Message)" -type 3 -component "deploymentChecker"
                        continue
                    }
                    $mandatoryUserColAdvExists = $false
                    foreach ($objToDeploy in ($deployment.ObjectsToDeploy.ObjectToDeploy | Where {$_.ObjectID -notlike "Scope*"})) {
                        $found = $false
                        $foundAdvType = $Null
                        foreach ($adv in $allPackageAdvertisements) {
                            if ($adv.PackageID -eq $objToDeploy.ObjectID -and $adv.ProgramName -eq $objToDeploy.ProgramName) {
                                $found = $true
                                $foundAdvType = $adv.OfferType
                                break
                            }
                        }
                        $writeMsg = $true
                        if ($collectionObject.CollectionType -eq 1 -and $mandatoryDeployment -eq $true) {
                            LogToCMTraceFile -message "-------- deployment targets user collection even when it is set as mandatory." -type 1 -component "deploymentChecker"
                            if ($found = $true -and $foundAdvType -eq 0) {
                                LogToCMTraceFile -message "---------- deployment should not exist! Warning: user collection is targeted by a mandatory deployment!" -type 1 -component "deploymentChecker"
                                $mandatoryUserColAdvExists = $true
                            } elseif ($found -eq $false) {
                                LogToCMTraceFile -message "---------- deployment does not exist. Counting the deployment as existing" -type 1 -component "deploymentChecker"
                                $found = $true
                                $writeMsg = $false
                            }
                        }
                        if ($found -eq $true) {
                            if ($writeMsg -eq $true) {
                                LogToCMTraceFile -message "-------- $($objToDeploy.ObjectID):$($objToDeploy.ProgramName) is deployed as it should" -type 1 -component "deploymentChecker"
                            }
                        } else {
                            LogToCMTraceFile -message "-------- $($objToDeploy.ObjectID):$($objToDeploy.ProgramName) is no longer deployed!" -type 2 -component "deploymentChecker"
                            $modifiedOutsideScript = $true
                        }
                    }

                    foreach ($objToDeploy in ($deployment.ObjectsToDeploy.ObjectToDeploy | Where {$_.ObjectID -like "Scope*"})) {
                        $found = $false
                        $foundAdvType = $null
                        foreach ($adv in $allApplicationAdvertisements) {
                            if ($($adv.AssignedCI_UniqueID) -like "$($_.ObjectID)*") {
                                $found = $true
                                $foundAdvType = $adv.OfferTypeID
                                break
                            }
                        }
                        $writeMsg = $true
                        if ($collectionObject.CollectionType -eq 1 -and $mandatoryDeployment -eq $true) {
                            LogToCMTraceFile -message "-------- deployment targets user collection even when it is set as mandatory. " -type 1 -component "deploymentChecker"
                            if ($found = $true -and $foundAdvType -eq 0) {
                                LogToCMTraceFile -message "---------- deployment should not exist! Warning: user collection is targeted by a mandatory deployment!" -type 1 -component "deploymentChecker"
                                $mandatoryUserColAdvExists = $true
                            } elseif ($found -eq $false) {
                                LogToCMTraceFile -message "---------- deployment does not exist. Counting the deployment as existing" -type 1 -component "deploymentChecker"
                                $found = $true
                                $writeMsg = $false
                            }
                        }
                        if ($found -eq $true) {
                            if ($writeMsg -eq $true) {
                                LogToCMTraceFile -message "-------- $($objToDeploy.ObjectID):$($objToDeploy.ProgramName) is deployed as it should" -type 1 -component "deploymentChecker"
                            }
                        } else {
                            LogToCMTraceFile -message "-------- $($objToDeploy.ObjectID):$($objToDeploy.ProgramName) is no longer deployed!" -type 2 -component "deploymentChecker"
                            $modifiedOutsideScript = $true
                        }
                    }
                }
            }
            if ($modifiedOutsideScript -eq $true) {
                LogToCMTraceFile -message "--- deployment was modified manually outside this script!" -type 2 -component "deploymentChecker"
                $deployment.SCCMInformation.Status = "Modified manually"
            } else {
                LogToCMTraceFile -message "--- deployment corresponds with XML settings" -type 1 -component "deploymentChecker"
                $deployment.SCCMInformation.Status = "Success"
            }
            if ($mandatoryUserColAdvExists -eq $true) {
                $deployment.SCCMInformation.Status = "Warning-8"
            }
            LogToCMTraceFile -message "---- COMPLETED ACTIONS FOR deployment $($deployment.ID), action nothing (only check)" -type 1 -component "deploymentChecker"
        }
    }
}

LogToCMTraceFile -message "Completed all actions! Saving new XML file" -type 1 -component "completed"
try {
    $deploymentsFile.Save($xmlDeploymentsFilePath)
} catch {
    LogToCMTraceFile -message "Error saving new file! Error message: $($_.Exception.Message)" -type 3 -component "completed"
}

LogToCMTraceFile -message "Quitting AutoScript.ps1" -type 1 -component "completed"