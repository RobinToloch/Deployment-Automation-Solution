﻿#Author Robin Toloch
#Version 1.02
#Creation date 26. 02. 2020
#Modified date 04. 03. 2020

#Purpose
#This solution creates XML files for depoyments that are later processed by AutoScript.PS1

#Fixes
#1.02
#- 04. 03. 2020
#- fixed a bug where empty lines in target user and computer list prevented other lines from being processed
#- edited condition for ad group list validation
#- fixed a bug where non existing xml deployments file would result into an error first while second attempt worked fine

#New features
#1.01 
#- 01. 03. 2020
#- added settings file that allows to change server and site name which should be used to apply the changes to.

#1.02
#- 04. 03. 2020
#- added settings for collection paths for device and user collections

Add-Type -AssemblyName System.Windows.Forms


$Global:logFile = "$($PSScriptRoot)\LogData\log.log"
$Global:deploymentLoaded = $false
$Global:deploymentLoading = $false
$Global:loadedDeployment = @{
    "DeploymentID" = 0;
}

$Global:SelectedObjects = @()

$Global:settingsObject = [PSCustomObject]@{"ServerName"="";"SiteName"="";"DeviceColPath"="";"UserColPath"=""}

#"Manufacturer, Name, Version, Language, ID" no language for Applications
#[PSCustomObject]@{Manufacturer="";Name="";Version="";Language="";ID=""}
#Index in listbox will correspond with index in array
$Global:LoadedObjects = @()

#LogToCMTraceFile -message "" -type 1 -component ""
Function show() {
    defaultFormSettings

    LogToCMTraceFile -message "---------------------------------------------------------------------" -type 1 -component "starting"
    LogToCMTraceFile -message "Date and time: $(Get-Date)" -type 1 -component "starting"
    LogToCMTraceFile -message "Starting application. Logged in user: $($env:USERDOMAIN)\$($env:USERNAME)" -type 1 -component "starting"
    
    $mainForm.ShowDialog()
}

Function validSettings {
    param ( $inputSettingsObject )

    if ($inputSettingsObject.serverName -eq $null -or $inputSettingsObject.siteName -eq $null -or $inputSettingsObject.siteName.Length -gt 3 -or $inputSettingsObject.DeviceColPath -eq $null -or $inputSettingsObject.UserColPath -eq $null) {
        return $false
    } else {
        return $true
    }
}

Function readSettingsXML {
    try {
        LogToCMTraceFile -message "Reading settings file" -type 1 -component "settingsRead"
        #reads and returns object with properties
        #PSCustomObject | ServerName=xxxx;SiteName=xxx
        $settingsFilePath = "$($PSScriptRoot)\settings.xml"
        if ((Test-Path -Path $settingsFilePath) -eq $true) {
            [xml]$settingsFile = Get-Content -Path $settingsFilePath
            $serverName = $settingsFile.appSettings.ServerName
            $siteName = $settingsFile.appSettings.SiteName
            $devColPath = $settingsFile.appSettings.DeviceCollectionPath
            $userColPath = $settingsFile.appSettings.UserCollectionPath
            if ($serverName -eq $null -or $siteName -eq $null -or $siteName.Length -gt 3 -or $devColPath -eq $null -or $userColPath -eq $null) {
                LogToCMTraceFile -message "-- invalid settings. Server name: $($serverName), Site name: $($siteName), Device collection path: $($devColPath), User collection path: $($userColPath)" -type 2 -component "settingsRead"
            } else {
                LogToCMTraceFile -message "-- successfully retrieved settings. Server name: $($serverName), Site name: $($siteName), Device collection path: $($devColPath), User collection path: $($userColPath)" -type 1 -component "settingsRead"
            }
            return [PSCustomObject]@{"ServerName"=$serverName;"SiteName"=$siteName;"DeviceColPath"=$devColPath;"UserColPath"=$userColPath}
        } else {
            LogToCMTraceFile -message "-- the settings file does not exist" -type 2 -component "settingsRead"
            return $false
        }
    } catch {
        LogToCMTraceFile -message "-- error reading the file. Error message $($_.exception.message)" -type 3 -component "settingsRead"
        return 1
    }
}

Function writeSettingsXML {
    param (
        $serverName,
        $siteName,
        $devColPath,
        $userColPath
    )
    #try {
        LogToCMTraceFile -message "Writing new settings file" -type 1 -component "settingsWrite"
        $settingsFilePath = "$($PSScriptRoot)\settings.xml"
        $settingsFile = $null
        #if ((Test-Path -Path $settingsFilePath) -eq $false) {
            #LogToCMTraceFile -message "-- file does not exist, creating a new xml document" -type 1 -component "settingsWrite"
        LogToCMTraceFile -message "-- creating a new xml document" -type 1 -component "settingsWrite"
            $newXMLObject = New-Object System.Xml.XmlDocument
        
            $xmlDeclaration = $newXMLObject.CreateXmlDeclaration("1.0","UTF-8",$null)
            $newXMLObject.AppendChild($xmlDeclaration)

            $appSettingsNode = $newXMLObject.CreateElement("element","appSettings",$null)
            $newXMLObject.AppendChild($appSettingsNode)

            $serverNameElement = $newXMLObject.CreateElement("element","serverName",$null)
            $appSettingsNode.AppendChild($serverNameElement)

            $siteNameElement = $newXMLObject.CreateElement("element","siteName",$null)
            $appSettingsNode.AppendChild($siteNameElement)

            $DeviceCollectionPathElement = $newXMLObject.CreateElement("element","deviceCollectionPath",$null)
            $appSettingsNode.AppendChild($DeviceCollectionPathElement)

            $UserCollectionPathElement = $newXMLObject.CreateElement("element","userCollectionPath",$null)
            $appSettingsNode.AppendChild($UserCollectionPathElement)

            $settingsFile = $newXMLObject
            #$newXMLObject.Save($settingsFilePath)
        #} else {
            #$settingsFile = [xml](Get-Content -Path $settingsFilePath)
        #}

        $settingsFile.appSettings.ServerName = $serverName
        $settingsFile.appSettings.siteName = $siteName
        $settingsFile.appSettings.deviceCollectionPath = $devColPath
        $settingsFile.appSettings.UserCollectionPath = $userColPath
        LogToCMTraceFile -message "-- saving new XML settings. Server name: $($serverName), Site name: $($siteName), Device collection path: $($devColPath), User collection path: $($userColPath)" -type 1 -component "settingsWrite"
        $settingsFile.Save($settingsFilePath)

        $Global:settingsObject = readSettingsXML

        return $true
    #} catch {
        return $false
        LogToCMTraceFile -message "-- error while saving new XML settings. Error message: $($_.exception.message)" -type 3 -component "settingsWrite"
    #}
}



Function IsAutoScriptRunning {
    $processes = @(Get-WmiObject -Namespace root\cimv2 -Query "select CommandLine from win32_process where name='powershell.exe' and CommandLine like '%AutoScript.ps1%'")
    #$processes = @(Get-WmiObject -Namespace root\cimv2 -Query "select CommandLine from win32_process where name='notepad.exe'")
    if ($processes.Count -ne 0) {
        return $true
    } else {
        return $false
    }
}

#simple log to cm trace file function
function LogToCMTraceFile {
    param (
        [Parameter(Mandatory=$true)]
        [ValidateNotNull()]
        [string]$message,

        [Parameter(Mandatory=$true)]
        [ValidateNotNull()]
        [int]$type,

        #1 - information
        #2 - warning
        #3 - error
        #4 - verbose


        [Parameter(Mandatory=$true)]
        [ValidateNotNull()]
        [string]$component,

        [Parameter(Mandatory=$false)]
        [int]$thread,

        [Parameter(Mandatory=$false)]
        [string]$file
    )
    If($type -lt 1 -or $type -gt 4) {
        Throw "Type must be between 1-4"
    }
    If($file -ne "" -and $thread -eq ""){
        Throw "You must specify thread, if you wish to use -file switch"
    }

    $Time = (Get-Date -Format "HH:mm:ss.fff-fff")
    $Date = (Get-Date -Format "MM-dd-yyyy")

    $LogStructure = "<![LOG[$($message)]LOG]!><time=""$($Time)"" date=""$($Date)"" component=""$($component)"" context="""" type=""$($type)"" thread=""$($hread)"" file=""$($file)"">"
    createFolderStructure -path $Global:logFile.Substring(0,$Global:logFile.LastIndexOf("\")) | Out-Null
    Out-File -FilePath $Global:logFile -Append -InputObject $LogStructure -Force -Encoding utf8
}

Function createFolderStructure {
    #function to create folder structure for given path, the path should not end with \ and should not contain file name
    param (
        [string]$path
    )
    if ((Test-Path -Path $path) -eq $true) { return $true }
    $pathBuilder = ""
    foreach ($part in $path.Split("\")) {
        $pathBuilder+=$part + "\"
        if ((Test-Path -Path $pathBuilder) -eq $false) {
            New-Item -Path $pathBuilder -ItemType "directory" -Force | Out-Null
        }
    }
    LogToCMTraceFile -message "Creating folder structure for $($path). Logged in user: $($env:USERDOMAIN)\$($env:USERNAME)" -type 1 -component "folderCreator"
}
Function defaultFormSettings() {
    $lblChooseDeployment.Visible = $false
    $lbDeployments.Visible = $false
    
    $btnLoad.Text = "Load"
    $btnCancel.Enabled = $false

    $btnCreate.Text = "Create"
    $btnCreate.Enabled = $true

    $Global:deploymentLoaded = $false
    $Global:deploymentLoading = $false
    $Global:loadedDeployment.DeploymentID = 0

    $txtDeploymentName.Text = ""
    $txtTargetComputersAndUsers.Text = ""
    $txtTargetADGroups.Text = ""
    $txtReason.Text = ""

    $lbChangesToDeployment.Items.Clear()

    $cbSCCMObjectToDeploy.Items.Clear()
    $cbSCCMProgramToDeploy.Items.Clear()
    
    $opbApplications.Checked = $false
    $opbPackages.Checked = $false
    
    $txtfilter.Text = ""
    
    $lbObjectsToDeploy.Items.Clear()

    $btnLoad.Enabled = $true

    $availableDateTime.Value = [System.DateTime]::Now
    $deadlineDateTime.Value = [System.DateTime]::Now

    $availableDateTime.MinDate = [System.DateTime]::Today.AddDays(-1)
    $deadlineDateTime.MinDate = [System.DateTime]::Today.AddDays(-1)

    $btnDelete.Enabled = $false

    $lblDeploymentName.Visible = $true
    $txtDeploymentName.Visible = $true

    $lblReason.Visible = $true
    $txtReason.Visible = $true

    $lblAvailableDate.Visible = $true
    $availableDateTime.Visible = $true

    $lblDeadlineDate.Visible = $true
    $deadlineDateTime.Visible = $true

    $checkboxAvailable.Visible = $true
    $checkBoxDeadline.Visible = $true

    $lblTargetComputersAndUsers.Visible = $true
    $txtTargetComputersAndUsers.Visible = $true

    $lblTargetADGroups.Visible = $true
    $txtTargetADGroups.Visible = $true

    $lblNextAction.Visible = $true
    $txtNextAction.Visible = $true

    $lblSCCMStatus.Visible = $true
    $txtSCCMStatus.Visible = $true

    $lblColID.Visible = $true
    $txtColID.Visible = $true

    $lblColName.Visible = $true
    $txtColName.Visible = $true
    
    $lblChangesToDeployment.Visible = $true
    $lbChangesToDeployment.Visible = $true
}

Function showDeploymentMenu {
    $lblChooseDeployment.Visible = $true
    $lbDeployments.Visible = $true

    $btnCancel.Enabled = $true
    $btnCreate.Enabled = $false
    $btnDelete.Enabled = $false
    $btnLoad.Text = "Confirm"

    $lblDeploymentName.Visible = $false
    $txtDeploymentName.Visible = $false

    $lblReason.Visible = $false
    $txtReason.Visible = $false

    $lblAvailableDate.Visible = $false
    $availableDateTime.Visible = $false

    $lblDeadlineDate.Visible = $false
    $deadlineDateTime.Visible = $false

    $checkboxAvailable.Visible = $false
    $checkBoxDeadline.Visible = $false

    $lblTargetComputersAndUsers.Visible = $false
    $txtTargetComputersAndUsers.Visible = $false

    $lblTargetADGroups.Visible = $false
    $txtTargetADGroups.Visible = $false

    $lblNextAction.Visible = $false
    $txtNextAction.Visible = $false

    $lblSCCMStatus.Visible = $false
    $txtSCCMStatus.Visible = $false

    $lblColID.Visible = $false
    $txtColID.Visible = $false

    $lblColName.Visible = $false
    $txtColName.Visible = $false
    
    $lblChangesToDeployment.Visible = $false
    $lbChangesToDeployment.Visible = $false
}

Function loadDeployments {
    try {
        $targetPath = "$($PSScriptRoot)\DeploymentData\deployments.xml"
        if ((Test-Path -Path $targetPath) -eq $false) { throw "File $($targetPath) does not exit!" }
        [xml]$xmlDeployments = Get-Content $targetPath

        $lbDeployments.Items.Clear()

        foreach ($deployment in $xmlDeployments.Deployments.Deployment) {
            #write-host "$($deployment.ID) - $($deployment.NAME)"
            $lbDeployments.Items.Add("$($deployment.ID);  $($deployment.NAME); $($deployment.NextAction.Name); $($deployment.SCCMInformation.Status)") | out-null
        }
        
        return $true
    } catch {
        LogToCMTraceFile -message "Could not load deployment list. Error: $($_.exception.message). Logged in user: $($env:USERDOMAIN)\$($env:USERNAME)" -type 3 -component "deploymentListLoader"
        return $false
    }
}

Function loadDeployment {
    param ( 
        #[ValidateNotNull()]
        #[string]$deploymentID=""
    )
    try {
        $deploymentID = $lbDeployments.Items[$lbDeployments.SelectedIndex].Substring(0,$lbDeployments.Items[$lbDeployments.SelectedIndex].IndexOf(";"))
        LogToCMTraceFile -message "Loading deployment $($deploymentID). Logged in user: $($env:USERDOMAIN)\$($env:USERNAME)" -type 1 -component "deploymentLoader"
        [xml]$xmlDeployments = Get-Content "$($PSScriptRoot)\DeploymentData\deployments.xml"
    
        #select deployment from xml file by filtering the deployment id property
        $deploymentToLoad = $xmlDeployments.Deployments.Deployment | where {$_.ID -eq $deploymentID}
    
        $Global:deploymentLoading = $true

        $txtDeploymentName.Text = $deploymentToLoad.Name
        $txtReason.Text = $deploymentToLoad.CreatedBy.Reason
    
        $availableDateTime.MinDate = [System.DateTime]::Today.AddYears(-2)
        $deadlineDateTime.MinDate = [System.DateTime]::Today.AddYears(-2)
    
        #culture info is required here if we want to get the date which is in format dd. MM. yyyy HH:mm:ss which we then change to MM. dd etc. format which is supported by date time picker component
        $csLocale = New-Object system.globalization.cultureinfo("cs-CS")

        if ($deploymentToLoad.AvailableTime.DateTime -ne "notset") {
            $availableDateTime.Value = $(Get-Date $([DateTime]::ParseExact($deploymentToLoad.AvailableTime.DateTime,"dd. MM. yyyy HH:mm:ss",$csLocale)) -Format "MM. dd. yyyy HH:mm:ss")
            $checkboxAvailable.Checked = $true
        } else {
            $checkboxAvailable.Checked = $false
        }

        if ($deploymentToLoad.DeadlineTime.DateTime -ne "notset") {
            $deadlineDateTime.Value = $(Get-Date $([DateTime]::ParseExact($deploymentToLoad.DeadlineTime.DateTime,"dd. MM. yyyy HH:mm:ss",$csLocale)) -Format "MM. dd. yyyy HH:mm:ss")
            $checkBoxDeadline.Checked = $true
        } else {
            $checkBoxDeadline.Checked = $false
        }

        $txtTargetADGroups.Text = $deploymentToLoad.AdGroups.AdGroup.Name -join [Environment]::NewLine

        $txtNextAction.text = $deploymentToLoad.NextAction.Name
        $txtColID.Text = $deploymentToLoad.SCCMInformation.ColID
        $txtColName.Text = $deploymentToLoad.SCCMInformation.ColName
        $txtSCCMStatus.Text = $deploymentToLoad.SCCMInformation.Status

        $lbChangesToDeployment.Items.Add("$($deploymentToLoad.CreatedBy.UserName); $($deploymentToLoad.CreatedBy.DateTime); $($deploymentToLoad.CreatedBy.Reason)")
        foreach ($change in $deploymentToLoad.Changes.Change) {
            $lbChangesToDeployment.Items.Add("$($change.UserName); $($change.DateTime); $($change.Action); $($change.Reason)") |out-null
        }
    
        if ((loadSourceList -deploymentID $deploymentToLoad.ID) -eq $false) {
            $txtTargetComputersAndUsers.Text = "Error loading the list!"
        }

        foreach ($objectToDeploy in $deploymentToLoad.ObjectsToDeploy.ObjectToDeploy) {
            If ($objectToDeploy.ObjectID -like "ScopeID*") {
                $lbObjectsToDeploy.Items.Add($(getApplicationInformation -modelName $objectToDeploy.ObjectId)) | out-null
            } else {
                $lbObjectsToDeploy.Items.Add("$(getPackageInformation -packageid $objectToDeploy.ObjectId);$($objectToDeploy.ProgramName)") | out-null
            }
        }

        $Global:deploymentLoaded = $true
        $Global:loadedDeployment.DeploymentID = $deploymentToLoad.ID
        $Global:deploymentLoading = $false

        LogToCMTraceFile -message "Successfully loaded deployment $($deploymentID). Logged in user: $($env:USERDOMAIN)\$($env:USERNAME)" -type 1 -component "deploymentLoader"
        
        return $true
    } catch {
        LogToCMTraceFile -message "Could not load deployment $($deploymentID). Error: $($_.exception.message). Logged in user: $($env:USERDOMAIN)\$($env:USERNAME)" -type 3 -component "deploymentLoader"
        return $false
    }
}

#these function are used to load objects that are deployed in the created deployment
Function getApplicationInformation {
    param ($modelName)

    #find the last civersion first

    $highestCiVersion = (Get-WmiObject -Namespace "root\sms\site_$($Global:settingsObject.SiteName)" -ComputerName $Global:settingsObject.ServerName -Query "Select CiVersion from SMS_APPLICATION where ModelName='$($modelName)'" | Sort CiVersion -Descending | Select -First 1).CiVersion
    $uniqueID = "$($modelName)/$($highestCiVersion)"
    $application = Get-WmiObject -Namespace "root\sms\site_$($Global:settingsObject.SiteName)" -ComputerName $Global:settingsObject.ServerName -Query "Select Manufacturer,LocalizedDisplayName,SoftwareVersion from SMS_APPLICATION where CI_UNIQUEID='$($uniqueID)'"
    
    return "$($application.Manufacturer);$($application.LocalizedDisplayName);$($application.SoftwareVersion);;$($modelname)"
}

Function getPackageInformation {
    param ($packageID)
    
    $package = Get-WmiObject -Namespace "root\sms\site_$($Global:settingsObject.SiteName)" -ComputerName $Global:settingsObject.ServerName -Query "Select Manufacturer,Name,Version,Language from SMS_PACKAGE where PackageId='$($packageID)'"
    
    return "$($package.Manufacturer);$($package.Name);$($package.Version);$($package.Language);$($packageID)"
}

Function validateTargetList {
    $badEntries = @()
    foreach ($line in $txtTargetComputersAndUsers.Lines) {
        if ($line.Trim() -ne "" -and $($line.Trim().SubString(0,3) -ne "CN:")) {
            if ($line.Trim().Length -le 3) {
                $badEntries += $line.Trim()
            } elseif ($line.Trim().Length -ge 26) {
                $badEntries += $line.Trim()
            } elseif ($line.Trim().Length -ge 4 -and $line.Trim().Length -lt 26) {
                if ($($line.Trim().SubString(0,3) -ne "UC:") -and $($line.Trim().SubString(0,3) -ne "DC:")) {
                    $badEntries += $line.Trim()
                }
            }
        }
    }   
    if ($badEntries.Count -eq 0) { 
        return $false
    } else {
        return $badEntries
    }
}

Function createTargetList { 
    param ( [string]$deploymentID )
    try {
        $targetFilePath = "$($PSScriptRoot)\DeploymentData\TargetFiles\$($deploymentID)_Source.csv"
        if (Test-Path -Path $targetFilePath) { Remove-Item -Path $targetFilePath -Force }

        New-Item -Path $targetFilePath -Force
        $itemsInTheFile = @()
        #write-host $txtTargetComputersAndUsers.Lines.Count
        foreach ($line in $txtTargetComputersAndUsers.Lines) {
        #write-host $line
            if ($line -ne "" -and $line.Length -le 25 -and $line.Length -gt 3) {
                if (($line.SubString(0,3) -eq "UC:")) {
                    $itemToFile = "$($line.SubString(3,$line.Length-3).Trim());user"
                    if ($itemToFile -notin $itemsInTheFile) {
                        Out-File -FilePath $targetFilePath -Append -Force -InputObject $itemToFile
                        $itemsInTheFile += $itemToFile
                    }
                } elseif (($line.SubString(0,3) -eq "DC:")) {
                    $itemToFile = "$($line.SubString(3,$line.Length-3).Trim());computer"
                    if ($itemToFile -notin $itemsInTheFile) {
                        Out-File -FilePath $targetFilePath -Append -Force -InputObject $itemToFile
                        $itemsInTheFile += $itemToFile
                    }
                }
            }
            if ($line -ne "" -and $line.Length -gt 3) {
                if ($($line.Trim().SubString(0,3) -eq "CN:")) {
                    $itemToFile = "$($line.SubString(3,$line.Length-3).Trim());collection"
                    if ($itemToFile -notin $itemsInTheFile) {
                        Out-File -FilePath $targetFilePath -Append -Force -InputObject $itemToFile
                        $itemsInTheFile += $itemToFile
                    }
                }
            }
        }
        return $true
    } catch {
        LogToCMTraceFile -message "Failed to create file with users and computers! Error message: $($_.exception.message). Logged in user: $($env:USERDOMAIN)\$($env:USERNAME)" -type 3 -component "listCreation"
        return $false
    }
}

Function loadSourceList {
    param (
        $deploymentID,
        $targetFilePath
    )
    try {
        if ($deploymentID -ne -1) {
            $targetFilePath = "$($PSScriptRoot)\DeploymentData\TargetFiles\$($deploymentID)_Source.csv"
        }
        If (Test-Path -Path $targetFilePath) {
            $computersInFile = Import-Csv -Path $targetFilePath -Delimiter ";" -Header "Name","Type"
            $validatedList = validateList -input $computersInFile
            if ($validatedList -eq $false) { 
                $validatedList = "Corrupted target list" 
            } else { 
                if ($deploymentID -ne -1) {
                    $txtTargetComputersAndUsers.Text = ($validatedList) -join [Environment]::NewLine
                } else {
                    if ($txtTargetComputersAndUsers.Text -eq "") {
                        $txtTargetComputersAndUsers.Text = ($validatedList) -join [Environment]::NewLine
                    } else {
                        #$txtTargetComputersAndUsers.Text += [Environment]::NewLine
                        $txtTargetComputersAndUsers.Text += "$([Environment]::NewLine)$(($validatedList) -join [Environment]::NewLine)"
                    }
                }
            }
            return $true
        } else {     
            LogToCMTraceFile -message "File with users and computers does not exit! Expected path $($targetFilePath). Logged in user: $($env:USERDOMAIN)\$($env:USERNAME)" -type 3 -component "sourceListLoader"
            return $false
        }
    } catch {
        LogToCMTraceFile -message "Error loading the file with users and computers! Path $($targetFilePath). Error message: $($_.exception.message). Logged in user: $($env:USERDOMAIN)\$($env:USERNAME)" -type 3 -component "sourceListLoader"
        return $false
    }
}

Function validateList {
    param ( 
        $inputCSV
    )
    try {
        #csv file contains NAME, TYPE columns. Filter through the values and make sure the length is not longer than 22 characters and filter out duplicate values
        $outputArrayForTxtBox = @()
        foreach ($object in $inputCSV) {
            if ($object.Name -ne "" -and $object.Name.Lenth -le 22) {
                if ($object.Type.Trim() -eq "computer") {
                    #$([Environment]::NewLine)
                    if ("DC:$($object.Name)" -notin $outputArrayForTxtBox) { $outputArrayForTxtBox+="DC:$($object.Name.Trim())" }
                } elseif ($object.Type -eq "user") {
                    if ("UC:$($object.Name)" -notin $outputArrayForTxtBox) { $outputArrayForTxtBox+="UC:$($object.Name.Trim())" }
                }
            }
            if ($object.Type.Trim() -eq "collection") {
                if ("CN:$($object.Name)" -notin $outputArrayForTxtBox) { $outputArrayForTxtBox+="CN:$($object.Name.Trim())" }
            }
        }
        return $outputArrayForTxtBox
    } catch {
        LogToCMTraceFile -message "A problem occured while validating target list. Error message: $($_.exception.message)" -type 2 -component "valiteTargetList"
        return $false
    }
}

Function validateAdGroupList {
    try {
        $outputArray = @()
        foreach($line in $txtTargetADGroups.Lines) {
            if (($line -like "UC:*" -or $line -like "DC:*") -and $line -ne "" -and ($line.Length -le 256 -and $line.Length -gt 3) -and $line -notin $outputArray) { 
                $outputArray += $line.Trim() 
            }
        }
        return $outputArray
    } catch {
        LogToCMTraceFile -message "A problem occured while validating AD group list. Error message: $($_.exception.message)" -type 2 -component "valiteADList"
    }
}

Function getAvailableIDNumber {
    try {
        $targetPath = "$($PSScriptRoot)\DeploymentData\deployments.xml"
        [xml]$targetFile = Get-Content -Path $targetPath

        $highest = -1
        foreach ($deploymentID in $targetFile.Deployments.Deployment.ID) {
            $intDeploymentID = [convert]::ToInt16($deploymentID.Substring(1,4))
            if ($intDeploymentID -gt $highest) {$highest = $intDeploymentID}
        }
        $highest++
        #function padleft allows us to make string X characters long and add dummy characters before or after the string. Params: desired length, dummy character
        $highest = [convert]::ToString($highest).PadLeft(4,"0")
        return "D$highest"
    } catch {
        LogToCMTraceFile -message "Could not get an available ID for the new deployment. Error message: $($_.exception.message)" -type 3 -component "getAvailableID"
        return $false
    }
}

Function createOrModifyXMLdeployment {
    param (
        #can be Delete, Create or Modify
        $action
    )
    try {
        LogToCMTraceFile -message "Create a new deployment function. Action: $($action). Logged in user: $($env:USERDOMAIN)\$($env:USERNAME)" -type 1 -component "deploymentCreator"
        $targetPath = "$($PSScriptRoot)\DeploymentData\deployments.xml"
        if ((Test-Path -Path $targetPath) -eq $false) {
            if ((createEmptyXMLfile) -eq $false) { return $false }
        } 
        [xml]$targetFile = Get-Content -Path $targetPath
        #it is better to select nodes using .ChildNotes | where {$_.LocalName -eq "XXX"} because then we can work with it with less effort.
        #if the node was empty, simply getting it using .NodeName would not work because it would return an empty string which of course does not contain xml methods
        $xmlDeployments = $targetFile.ChildNodes | where {$_.LocalName -eq "Deployments"}

        #create or modify the nodes one by one instead of having one big condition per each action

        #START ---- Specific deployment node; main node used for the deployment, it contains all the properties.
        $deploymentID = ""
        $xmlDeployment = $null
        if ($action -ne "Create") {
            $xmlDeployment = $xmlDeployments.Deployment | Where {$_.ID -eq $Global:loadedDeployment.DeploymentID}
            $deploymentID = $Global:loadedDeployment.DeploymentID
            if ($action -ne "Delete") { $xmlDeployment.SetAttribute("Name",$txtDeploymentName.Text) }

            LogToCMTraceFile -message "Loaded deployment id $($Global:loadedDeployment.DeploymentID). Logged in user: $($env:USERDOMAIN)\$($env:USERNAME)" -type 1 -component "deploymentCreator"
        } else {
            $xmlDeployment = $targetFile.CreateElement("element","Deployment",$null)
            $newID = getAvailableIDNumber
            $deploymentID = $newID
            if ($newID -eq $false) { throw "Could not get a new ID, cannot continue" }
            $xmlDeployment.SetAttribute("ID",$($newID))
            $xmlDeployment.SetAttribute("Name",$txtDeploymentName.Text)
            $xmlDeployment.SetAttribute("CreatedOn",$(Get-Date -Format "dd. MM. yyyy HH:mm:ss"))
            $xmlDeployments.AppendChild($xmlDeployment)

            LogToCMTraceFile -message "New deployment id $(getAvailableIDNumber). Logged in user: $($env:USERDOMAIN)\$($env:USERNAME)" -type 1 -component "deploymentCreator"
        }
        #END ---- deployment node
    
        #START ---- AdGroups; AdGroups element is always created even if there are no ad groups for the deployment
        $xmlAdGroups = $null
        if ($action -eq "Create") {
            $xmlAdGroups = $targetFile.CreateElement("element","AdGroups",$null)
            $xmlDeployment.AppendChild($xmlAdGroups)
        } elseif ($action -eq "Modify") {
            $xmlAdGroups = $xmlDeployment.ChildNodes | Where {$_.LocalName -eq "AdGroups"}   

            #remove ADGroup elements from AdGroups, if there are none, the foreach cycle will not even begin
            foreach ($grp in $xmlDeployment.AdGroups.AdGroup) {
                $xmlDeployment.AdGroups.RemoveChild($grp)
            }
        }
        if ($action -ne "Delete") {
            #remove all AdGroup elements if action is not delete.
            #validate and set target ad groups - used as a source
            $txtTargetADGroups.Text = (validateAdGroupList) -join [Environment]::NewLine
            if ($txtTargetADGroups.Text -ne "") {
                foreach ($group in $txtTargetADGroups.Lines) {
                    #create AdGroup element for each line (one line per ad group)
                    $newGroup = $targetFile.CreateElement("element","AdGroup",$null)
                    $newGroup.SetAttribute("Name",$group.Trim())
                    $xmlAdGroups.AppendChild($newGroup)
                }
            }
        }
        #END ---- AdGroups
    
        #START ---- Objects to deploy / ObjectsToDeploy / ObjectToDeploy ID ProgramName
        $xmlObjectsToDeploy = $null
        if ($action -eq "Create") {
            $xmlObjectsToDeploy = $targetFile.CreateElement("element","ObjectsToDeploy",$null)
            $xmlDeployment.AppendChild($xmlObjectsToDeploy)
        } else {
            $xmlObjectsToDeploy = $xmlDeployment.ChildNodes | Where {$_.LocalName -eq "ObjectsToDeploy"}
        }
        if ($xmlObjectsToDeploy.ObjectToDeploy -ne $null) {
            foreach ($objectToDeploy in $xmlObjectsToDeploy.ObjectToDeploy) {
                $xmlObjectsToDeploy.RemoveChild($objectToDeploy)
            }
        }
        foreach($item in $lbObjectsToDeploy.Items) {
            $newObjectToDeploy = $targetFile.CreateElement("elements","ObjectToDeploy",$null)

            $splitItem = $item.Split(";")
            #if count is 5 = application 0-4
            #if count is 6 = package 0-5
            if ($splitItem.count -eq 5) {
                #$newObjectToDeploy.SetAttribute("ObjectID",$splitItem[$splitItem.Count-1].SubString(0,$splitItem[$splitItem.Count-1].LastIndexOf("/")))
                $newObjectToDeploy.SetAttribute("ObjectID",$splitItem[$splitItem.Count-1])
                $newObjectToDeploy.SetAttribute("ProgramName","")
            } elseif ($splitItem.Count -eq 6) {
                $newObjectToDeploy.SetAttribute("ObjectID",$splitItem[$splitItem.Count-2])
                $newObjectToDeploy.SetAttribute("ProgramName",$splitItem[$splitItem.Count-1])
            }
            $xmlObjectsToDeploy.AppendChild($newObjectToDeploy)
        }
        #END ---- Objects to deploy

        #START ---- Available and Deadline time, if action is not delete
        if ($action -ne "Delete") {
            $xmlAvailableTime = $null
            if ($action -eq "Modify") {
                $xmlAvailableTime = $xmlDeployment.AvailableTime
            } else {
                $xmlAvailableTime = $targetFile.CreateElement("element","AvailableTime",$null)
                $xmlDeployment.AppendChild($xmlAvailableTime)
            }
            if ($checkboxAvailable.Checked) {
                $xmlAvailableTime.SetAttribute("DateTime",$availableDateTime.Text) 
            } else {
                $xmlAvailableTime.SetAttribute("DateTime","notset")
            }

            $xmldeadlineTime = $null
            if ($action -eq "Modify") {
                $xmldeadlineTime = $xmlDeployment.deadlineTime
            } else {
                $xmldeadlineTime = $targetFile.CreateElement("element","DeadlineTime",$null)
                $xmlDeployment.AppendChild($xmldeadlineTime)
            }
    
            if ($checkBoxDeadline.Checked) {
                $xmldeadlineTime.SetAttribute("DateTime",$deadlineDateTime.Text)
            } else {
                $xmldeadlineTime.SetAttribute("DateTime","notset")
            }
        }
        #END ---- Available and Deadline time

        #START ---- NextAction
        $xmlnextAction = $null
        if ($action -ne "Create") {
            $xmlnextAction = $xmlDeployment.NextAction
        } else {
            $xmlnextAction = $targetFile.CreateElement("element","NextAction",$null)
            $xmlDeployment.AppendChild($xmlnextAction)
        }
        $xmlnextAction.SetAttribute("Name",$action)
        #END ---- NextAction

        #START ---- CreatedBy, Changes and Change elements
        if ($action -eq "Create") {
            $xmlCreatedBy = $targetFile.CreateElement("element","CreatedBy",$null)
            $xmlCreatedBy.SetAttribute("UserName","$($env:USERDOMAIN)\$($env:USERNAME)")
            $xmlCreatedBy.SetAttribute("DateTime",$(Get-Date -format "dd.MM.yyyy HH:mm:ss"))
            $xmlCreatedBy.SetAttribute("Reason",$txtReason.Text)
            $xmlDeployment.AppendChild($xmlCreatedBy)

            $xmlChanges = $targetFile.CreateElement("element","Changes",$null)
            $xmlDeployment.AppendChild($xmlChanges)
            #$action -eq "Modify" -or $action -eq "Delete" -or $action -eq "Restore"
        } else {
            $xmlChanges = $xmlDeployment.ChildNodes | Where {$_.LocalName -eq "Changes"}

            $xmlChange = $targetFile.CreateElement("element","Change",$null)
            $xmlChange.SetAttribute("UserName","$($env:USERDOMAIN)\$($env:USERNAME)")
            $xmlChange.SetAttribute("DateTime",$(Get-Date -format "dd.MM.yyyy HH:mm:ss"))
            $xmlChange.SetAttribute("Action",$action)
            $xmlChange.SetAttribute("Reason",$txtReason.Text)
            $xmlChanges.AppendChild($xmlChange)
        }
        #END ---- CreatedBy, Changes and Change elements

        #START ---- SCCMInformation which is later used and modified by the action script
        if ($action -eq "Create") {
            $xmlSCCMInfo = $targetFile.CreateElement("element","SCCMInformation",$null)
            $xmlSCCMInfo.SetAttribute("ColID","")
            $xmlSCCMInfo.SetAttribute("ColName","")
            $xmlSCCMInfo.SetAttribute("Status","Pending")
            $xmlDeployment.AppendChild($xmlSCCMInfo)
        } else {
            $xmlSCCMInfo = $xmlDeployment.ChildNodes | Where {$_.Name -eq "SCCMInformation"}
            $xmlSCCMInfo.SetAttribute("Status","Pending")
        }
        #END ---- SCCMInformation

        if ((createTargetList -deploymentID $deploymentID) -eq $false) {
            throw "Creating a target list failed!"
        }

        LogToCMTraceFile -message "Saving new deployment file $($targetPath). Logged in user: $($env:USERDOMAIN)\$($env:USERNAME)" -type 1 -component "deploymentCreator"
        $targetFile.Save($targetPath)
        defaultFormSettings
        return $true
    } catch {
        LogToCMTraceFile -message "An error occured while running createormodify function. Error message: $($_.exception.message)" -type 3 -component "deploymentCreator"
        return $false
    }
}
#[System.Windows.Forms.MessageBox]::Show("This is my test","Test",[System.Windows.Forms.MessageBoxButtons]::YesNoCancel)
Function createEmptyXMLfile {
    try {
        $targetPath = "$($PSScriptRoot)\DeploymentData\deployments.xml"
        createFolderStructure -path "$($PSScriptRoot)\DeploymentData" | Out-Null

        LogToCMTraceFile -message "Creating a new xml file with deployments! $($targetPath). Logged in user: $($env:USERDOMAIN)\$($env:USERNAME)" -type 2 -component "deploymentCreator"
    
        [xml]$xmlContent = New-Object System.Xml.XmlDocument

        $declaration = $xmlContent.CreateXmlDeclaration("1.0","UTF-8",$null)
        $xmlContent.AppendChild($declaration)

        $deploymentsElement = $xmlContent.CreateElement("element","Deployments",$null)
        $xmlContent.AppendChild($deploymentsElement)
    
        $xmlContent.Save($targetPath)
        return $true
    } catch {
        LogToCMTraceFile -message "An error occured while running createemptyxml function. Error message: $($_.exception.message)" -type 3 -component "deploymentCreator"
        return $false
    }
}

Function validateLengthOfLines {
    param (
        [string]$txtBoxName,
        [int]$maxLength
    )
    try {
        $txtBoxControl = $mainForm.Controls.Find($txtBoxName,$true)
        $tooLong = $false
    
        for ($i=0;$i -lt $txtBoxControl.Lines.Count;$i++) {
            if ($txtBoxControl.Lines[$i].Length -gt $maxLength -and $txtBoxControl.Lines[0] -ne "MAX CHARACTER COUNT:$($maxLength)") {
                if ($txtBoxControl.Lines[$i].SubString(0,3) -ne "CN:") {
                    $tooLong = $true
                }
            }
        }
        return $tooLong
    } catch {
        LogToCMTraceFile -message "A problem occured while validating length of lines for control $($txtBoxName). Error message: $($_.exception.message)" -type 2 -component "validateLength"
    }
}

Function loadAllApplications() {
    #SMS_Application 
}
#"Manufacturer, Name, Version, Language, ID" no language for Applications
#[PSCustomObject]@{Manufacturer="";Name="";Version="";Language="";ID=""}
#Index in listbox will correspond with index in array
Function loadObjectsToDeploy() {
    param (
        [ValidateSet("Application","Package")]
        [string]$type
    )
    
    ShowLoading

    $cbSCCMObjectToDeploy.Items.Clear()
    $Global:LoadedObjects = @()

    switch ($type) {
        "Package" {
            $packages = Get-WmiObject -Namespace "root\sms\site_$($Global:settingsObject.SiteName)" -ComputerName $Global:settingsObject.ServerName -Query "Select Manufacturer,Name,Version,Language,PackageID from SMS_PACKAGE" | Sort Name
            foreach ($package in $packages) {
                $Global:LoadedObjects += @([PSCustomObject]@{Manufacturer=$package.Manufacturer;Name=$package.Name;Version=$package.Version;Language=$package.Language;ID=$package.PackageID})
                $cbSCCMObjectToDeploy.Items.Add("$($package.Manufacturer) $($package.Name) $($package.Version) $($package.Language) $($package.PackageID)")
            }
        }

        "Application" {
            #get all applications
            #where LocalizedDisplayName='Robin test'
            $applications = Get-WmiObject -Namespace "root\sms\site_$($Global:settingsObject.SiteName)" -ComputerName $Global:settingsObject.ServerName -Query "Select Manufacturer,LocalizedDisplayName,SoftwareVersion,CI_UniqueID,CIVersion,ModelName from SMS_APPLICATION" | Sort LocalizedDisplayName
            #process the result
            foreach ($application in $applications) {
                $appIsAlreadyLoaded = $false
                #go through each loaded application, if model name of a loaded application equals to app currently processing, modify its ci_uniqueid if currently processing app civersion is higher than the one we loaded before
                #if app in loaded array is modified, change boolean to true, if it is still false, add a new entry
                #write-host "Processing $($application.CI_UNIQUEID)"

                #another way of doing this would be following:
                #load all modelname properties from sms_application, for each modelname do a query for civersion, sort it by it and select the last civersion for each modelname
                #that actually sounds easier than the code below, but whatever. too lazy to rewrite it now
                
                #another note... this can all be changed to one single query using IsLatest='true' statement.......... perhaps in the next version, now it is working & tested.

                for($i=0;$i -lt $Global:LoadedObjects.Count;$i++) {
                    #get unique app id without version. CI_UNIQUEID =  MODELNAME/NUMBER

                    #get index of last slash /
                    #l is for text operation
                    #i represents index of object within loadedobjects array
                    for($l=$Global:LoadedObjects[$i].ID.Length-1;$l -gt 0;$l--) {
                        if ($Global:LoadedObjects[$i].ID.SubString($l,1) -eq "/") {
                            break
                        }
                    }
                    if ($l -eq 0) { continue }
                    #save already loaded object's properties MODELNAME and CIVERSION for comparision later on
                    $LoadedModelName = $Global:LoadedObjects[$i].ID.SubString(0,$l)
                    $LoadedCIVersion = $Global:LoadedObjects[$i].ID.SubString($l+1,$Global:LoadedObjects[$i].ID.Length-$l-1)
                    
                    #if ($application.LocalizedDisplayName -eq "Robin test") {
                    #    write-host "---- loaded is: $($LoadedModelName)/$($LoadedCIVersion)"
                    #    write-host "------ equals to processing app $($LoadedModelName -eq $application.modelname)"
                    #    write-host "------ is $($LoadedCIVersion) lower than $($application.CIVersion) $([int]$LoadedCIVersion -lt [int]$application.CIVersion)"
                    #}
                    #it is important to cast string to int for comparision! [int]XXX

                    #this set of conditions - first modelname (ID), second version is important because having it in one condition would not set appIsAlreadyInLoaded boolean to true if the app with higher version was in the list
                    #so we have to first look for the modelname and if the modelname corresponds, compare the version. if it is higher, change the object and if not, set appIsAlreadyLoaded to true so that it is not added to the array
                    #later on
                    if ($LoadedModelName -eq $application.modelname) {
                        if ([int]$LoadedCIVersion -lt [int]$application.CIVersion) {
                            #if modelname (unique ID) equals and version is higher, change the whole object to the newest found object
                            $Global:LoadedObjects[$i].ID = $application.CI_UNIQUEID
                            $Global:LoadedObjects[$i].Name = $application.LocalizedDisplayName
                            $Global:LoadedObjects[$i].Manufacturer = $application.Manufacturer
                            $Global:LoadedObjects[$i].Version = $application.SoftwareVersion
                            $appIsAlreadyLoaded = $true
                        } else {
                            $appIsAlreadyLoaded = $true
                        }
                    }

                    #Start-Sleep -Seconds 1
                }
                if ($appIsAlreadyLoaded -eq $false) {
                    $Global:LoadedObjects += @([PSCustomObject]@{Manufacturer=$application.Manufacturer;Name=$application.LocalizedDisplayName;Version=$application.SoftwareVersion;Language="";ID=$application.CI_UniqueID})
                }
            }

            #add applications to combobox only after we have made sure only the latest ci_uniqueid is loaded
            #append custom id for easier identification if filter was applied - CSID:N
            #CSID is needed because we didn't want to display uniqueci_id in combobox (it would be way too long and unnecessary). creating our own ID allows us to easily filter the application and have a unique
            #identifier which then helps us grab the object to add to the selected items list if the add button is clicked.
            #it is not needed for packages because packageid is the unique identifier.
            $customID = 0
            foreach ($loadedApp in $Global:LoadedObjects) {
                #$($loadedApp.ID)
                $cbSCCMObjectToDeploy.Items.Add("$($loadedApp.Manufacturer) $($loadedApp.Name) $($loadedApp.Version) CSID:$($customID)")
                $customID++
            }

        }
    }

    adjustDropDownWidth -control $cbSCCMObjectToDeploy
    HideLoading
}

Function getProgramsForPackage {
    param ([string]$packageID)
    ShowLoading
    $cbSCCMProgramToDeploy.Items.Clear()
    $allPrograms = Get-WmiObject -Namespace "root\sms\site_$($Global:settingsObject.SiteName)" -ComputerName $Global:settingsObject.ServerName -Query "Select ProgramName from sms_program where packageid='$($packageID)'" | Sort ProgramName
    #write-host $packageID
    foreach ($program in $allPrograms) {
        $cbSCCMProgramToDeploy.Items.Add($program.ProgramName)
    }
    HideLoading
}

Function adjustDropDownWidth {
    param ( $control )
    #$control = $mainForm.Controls.Find($cbControlName,$true)
    #adjust CB dropdown width accordingly
    $highest = 0
    foreach ($item in $control.Items) {
        $itemWidth = [System.Windows.Forms.TextRenderer]::MeasureText($item,$control.Font).Width
        if ($itemWidth -gt $highest) { $highest = $itemWidth }
    }
    if ($highest -gt $control.Width) { $highest += 30 }
    
    if ($highest -ne 0) { $control.DropDownWidth = $highest } else { $control.DropDownWidth = $control.Width }
}

Function ShowLoading {
    $lblLoading.Visible = $true
    $mainForm.Enabled = $false #change to false
}

Function HideLoading {
    $lblLoading.Visible = $false
    $mainForm.Enabled = $true
}

$mainForm = New-Object System.Windows.Forms.Form
$mainForm.Width = 450
$mainForm.Height = 800
$mainForm.Text = "Deployment Creator"
$mainForm.Name = "MainForm"
$mainForm.StartPosition = "CenterScreen"
$mainForm.Add_Load({

})
$mainForm.Add_Shown({
    $Global:settingsObject = readSettingsXML
    if ($Global:settingsObject -eq $false -or $Global:settingsObject -eq 1 -or ((validSettings -inputSettingsObject $Global:settingsObject) -eq $false)) {
        $settingsForm.ShowDialog()
    }
})
$mainForm.Add_Closing({
    LogToCMTraceFile -message "Closing application. Logged in user: $($env:USERDOMAIN)\$($env:USERNAME)" -type 1 -component "closing"
})

$lblLoading = New-Object System.Windows.Forms.Label
$lblLoading.AutoSize = $true
$lblLoading.Text = "LOADING . . ."
$lblLoading.Font = New-Object System.Drawing.Font("Arial",20,([System.Drawing.FontStyle]::Bold))
$lblLoading.Name = "lbLoading"
$lblLoading.BorderStyle = [System.Windows.Forms.BorderStyle]::FixedSingle
$lblLoading.Visible = $false
$mainForm.Controls.Add($lblLoading)
$lblLoading.Location = New-Object System.Drawing.Point((($mainForm.Width/2)-($lblLoading.Width/2)),(($mainForm.Height/2)-($lblLoading.Height/2)))

$opbApplications = New-Object System.Windows.Forms.RadioButton
$opbApplications.Text = "Applications"
$opbApplications.Name = "opbApplications"
$opbApplications.Checked = $false
$opbApplications.Location = New-Object System.Drawing.Point(200,25)
$opbApplications.Add_CheckedChanged({
    $cbSCCMObjectToDeploy.Items.Clear()
    $cbSCCMProgramToDeploy.Items.Clear()
    $cbSCCMObjectToDeploy.Text = ""
    $cbSCCMProgramToDeploy.Text = ""

    if ($opbApplications.Checked -eq $true) {
        $cbSCCMObjectToDeploy.Width = 415
        $cbSCCMObjectToDeploy.Height = 20

        loadObjectsToDeploy -type Application
    }
})
$mainForm.Controls.Add($opbApplications)

$opbPackages = New-Object System.Windows.Forms.RadioButton
$opbPackages.Text = "Packages"
$opbPackages.Name = "opbPackages"
$opbPackages.Checked = $false
$opbPackages.Location = New-Object System.Drawing.Point(325,25)
$opbPackages.Add_CheckedChanged({
    $cbSCCMObjectToDeploy.Items.Clear()
    $cbSCCMProgramToDeploy.Items.Clear()
    $cbSCCMObjectToDeploy.Text = ""
    $cbSCCMProgramToDeploy.Text = ""

    if ($opbPackages.Checked -eq $true) {
        $cbSCCMObjectToDeploy.Width = 250
        $cbSCCMObjectToDeploy.Height = 20

        loadObjectsToDeploy -type Package
    }
})
$mainForm.Controls.Add($opbPackages)

$lblFilter = New-Object System.Windows.Forms.Label
$lblFilter.AutoSize = $true
$lblFilter.Text = "Filter"
$lblFilter.Location = New-Object System.Drawing.Point(5,58)
$lblFilter.Name = "lblFilter"
$mainForm.Controls.Add($lblFilter)

$txtfilter = New-Object System.Windows.Forms.TextBox
$txtfilter.Width = 214
$txtfilter.Height = 20
$txtfilter.Visible = $true
$txtfilter.Location = New-Object System.Drawing.Point(40,56)
$mainForm.Controls.Add($txtfilter)
$txtfilter.Add_TextChanged({ 
    if ($opbPackages.Checked -eq $false -and $opbApplications.Checked -eq $false) { return }
    
    #filtering is quite easy, first we have to remove everything from the combobox prior to filtering itself
    #since all the objects are loaded in a variable, we can simply go through each item and see if any property corresponds
    #with the text we are looking for

    $cbSCCMObjectToDeploy.Items.Clear()
    $cbSCCMObjectToDeploy.Text = ""

    if ($txtfilter.Text -ne "") {
        foreach ($package in $Global:LoadedObjects) {
            if ($package.Manufacturer -like "*$($txtfilter.Text)*" -or $package.Name -like "*$($txtfilter.Text)*" -or $package.Version -like "*$($txtfilter.Text)*" -or $package.Language -like "*$($txtfilter.Text)*" -or $package.ID -like "*$($txtfilter.Text)*") {
                if ($opbPackages.Checked -eq $true) {
                    $cbSCCMObjectToDeploy.Items.Add("$($package.Manufacturer) $($package.Name) $($package.Version) $($package.Language) $($package.ID)")
                } else {
                    $cbSCCMObjectToDeploy.Items.Add("$($package.Manufacturer) $($package.Name) $($package.Version) $($package.Language) CSID:$($Global:LoadedObjects.IndexOf($package))")
                }
            }
        }
    } else {
        foreach ($package in $Global:LoadedObjects) {
                if ($opbPackages.Checked -eq $true) {
                    $cbSCCMObjectToDeploy.Items.Add("$($package.Manufacturer) $($package.Name) $($package.Version) $($package.Language) $($package.ID)")
                } else {
                    $cbSCCMObjectToDeploy.Items.Add("$($package.Manufacturer) $($package.Name) $($package.Version) $($package.Language) CSID:$($Global:LoadedObjects.IndexOf($package))")
                }
        }
    }

    adjustDropDownWidth -control $cbSCCMObjectToDeploy
})
$lblChoosePkgOrApp = New-Object System.Windows.Forms.Label
$lblChoosePkgOrApp.AutoSize = $true
$lblChoosePkgOrApp.Text = "Choose a package or an application"
$lblChoosePkgOrApp.Location = New-Object System.Drawing.Point(5,30)
$lblChoosePkgOrApp.Name = "lblChoosePkgOrApp"
$mainForm.Controls.Add($lblChoosePkgOrApp)

$lbObjectsToDeploy = New-Object System.Windows.Forms.ListBox
$lbObjectsToDeploy.Width = 415
$lbObjectsToDeploy.Height = 70
$lbObjectsToDeploy.Visible = $true
$lbObjectsToDeploy.Name = "lbObjectsToDeploy"
$lbObjectsToDeploy.Location = New-Object System.Drawing.Point(5,135)
$lbObjectsToDeploy.HorizontalScrollbar = $true
$lbObjectsToDeploy.Add_SelectedIndexChanged({
    #write-host $lbObjectsToDeploy.SelectedIndex
})
$mainForm.Controls.Add($lbObjectsToDeploy)

$cbSCCMObjectToDeploy = New-Object System.Windows.Forms.ComboBox
$cbSCCMObjectToDeploy.Name = "cbSCCMObjectToDeploy"
$cbSCCMObjectToDeploy.Width = 415
$cbSCCMObjectToDeploy.Height = 20
$cbSCCMObjectToDeploy.DropDownWidth = 400
$cbSCCMObjectToDeploy.Location = New-Object System.Drawing.Point(5,80)
$cbSCCMObjectToDeploy.Add_KeyPress({ 
    $_.Handled = $true
})
$cbSCCMObjectToDeploy.Add_TextChanged({
    if ($cbSCCMObjectToDeploy.Text -ne "" -and $opbPackages.Checked -eq $true) {
        #get index of selected item using the package id because filtering it and then using the selectedindex property would not work
        $splitProperties = $cbSCCMObjectToDeploy.Text.Split(" ")
        #package id is the last property in the text
        $packageID = $splitProperties[$splitProperties.Count-1]
        getProgramsForPackage -packageID $packageID
    }
})
$mainForm.Controls.Add($cbSCCMObjectToDeploy)

$cbSCCMProgramToDeploy = New-Object System.Windows.Forms.ComboBox
$cbSCCMProgramToDeploy.Name = "cbSCCMProgramToDeploy"
$cbSCCMProgramToDeploy.Width = 150
$cbSCCMProgramToDeploy.Height = 20
$cbSCCMProgramToDeploy.Location = New-Object System.Drawing.Point(270,80)
$cbSCCMProgramToDeploy.Add_KeyPress({ 
    $_.Handled = $true
})
$mainForm.Controls.Add($cbSCCMProgramToDeploy)

$btnAddToList = New-Object System.Windows.Forms.Button
$btnAddToList.Width = 80
$btnAddToList.Height = 25
$btnAddToList.Text = "Add to list"
$btnAddToList.Name = "btnAddToList"
$mainForm.Controls.Add($btnAddToList)
$btnAddToList.Location = New-Object System.Drawing.Point(5,104)
$btnAddToList.Add_Click({
    if ($cbSCCMObjectToDeploy.Text -eq "") {return}
        
    if ($opbPackages.Checked -eq $true) {
        if ($cbSCCMProgramToDeploy.Text -eq "") {return}
        $selectedItemParts = $cbSCCMObjectToDeploy.Text.Split(" ")
        $selectedItemID = $selectedItemParts[$selectedItemParts.Count-1]
        $curSelectedObj = $Global:LoadedObjects[$Global:LoadedObjects.ID.IndexOf($selectedItemID)]
        
        $itemForListbox = "$($curSelectedObj.Manufacturer);$($curSelectedObj.Name);$($curSelectedObj.Version);$($curSelectedObj.Language);$($curSelectedObj.ID);$($cbSCCMProgramToDeploy.Text)"
        if ($lbObjectsToDeploy.Items.IndexOf($itemForListbox) -ne -1) { return }
        
        $lbObjectsToDeploy.Items.Add($itemForListbox)

        $cbSCCMProgramToDeploy.Items.Clear()
        $cbSCCMProgramToDeploy.Text = ""
    } else {
        $curSelectedObj = $Global:LoadedObjects[[int]($cbSCCMObjectToDeploy.Text.Substring($cbSCCMObjectToDeploy.Text.IndexOf("CSID:")+5,$cbSCCMObjectToDeploy.Text.Length-$cbSCCMObjectToDeploy.Text.IndexOf("CSID:")-5))]
        
        $itemForListbox = "$($curSelectedObj.Manufacturer);$($curSelectedObj.Name);$($curSelectedObj.Version);$($curSelectedObj.Language);$($curSelectedObj.ID.SubString(0,$curSelectedObj.ID.LastIndexOf("/")))"
        if ($lbObjectsToDeploy.Items.IndexOf($itemForListbox) -ne -1) { return }

        $lbObjectsToDeploy.Items.Add($itemForListbox)
    }
    $cbSCCMObjectToDeploy.Text = ""
})

$btnRemoveToList = New-Object System.Windows.Forms.Button
$btnRemoveToList.Width = 100
$btnRemoveToList.Height = 25
$btnRemoveToList.Text = "Remove from list"
$btnRemoveToList.Name = "btnAddToList"
$mainForm.Controls.Add($btnRemoveToList)
$btnRemoveToList.Location = New-Object System.Drawing.Point(320,104)
$btnRemoveToList.Add_Click({
    if ($lbObjectsToDeploy.SelectedIndex -ne -1) {
        $lbObjectsToDeploy.Items.RemoveAt($lbObjectsToDeploy.SelectedIndex)
    }
})

$btnImportList = New-Object System.Windows.Forms.Button
$btnImportList.Width = 100
$btnImportList.Height = 25
$btnImportList.Text = "Import target list"
$btnImportList.Name = "btnImportList"
$mainForm.Controls.Add($btnImportList)
$btnImportList.Location = New-Object System.Drawing.Point(321,715)
$btnImportList.Add_Click({
    $fileBrowser = [System.Windows.Forms.OpenFileDialog]::new()
    $fileBrowser.Filter = "CSV files (*.csv)|*.csv"
    $result = $fileBrowser.ShowDialog()
    if ($result -eq "OK") {
        if ((Test-Path -Path $fileBrowser.FileName) -eq $true) {
            loadSourceList -deploymentID -1 -targetFilePath $fileBrowser.FileName
        }
    }
})


$lblLoggedInUser = New-Object System.Windows.Forms.Label
$lblLoggedInUser.AutoSize = $true
$lblLoggedInUser.Text = "Logged in user: $($env:USERDOMAIN)\$($env:USERNAME)"
$lblLoggedInUser.Location = New-Object System.Drawing.Point(5,715)
$lblLoggedInUser.Name = "lblLoggedInUser"
$lblLoggedInUser.Visible = $true
$mainForm.Controls.Add($lblLoggedInUser)

$lblHeader = New-Object System.Windows.Forms.Label
$lblHeader.AutoSize = $true
$lblHeader.Text = "Author: Robin Toloch, R.Toloch@seznam.cz"
$lblHeader.Location = New-Object System.Drawing.Point(5,735)
$lblHeader.Name = "lblHeader"
$lblHeader.Visible = $true
$mainForm.Controls.Add($lblHeader)

$groupBoxActions = New-Object System.Windows.Forms.GroupBox
$groupBoxActions.Width = 245
$groupBoxActions.Height = 50
$groupBoxActions.Text = "Select action"
$groupBoxActions.Name = "GroupBoxActions"
$groupBoxActions.Location = New-Object System.Drawing.Point(5,210)
$mainForm.Controls.Add($groupBoxActions)

$btnCreate = New-Object System.Windows.Forms.Button
$btnCreate.Width = 55
$btnCreate.Height = 25
$btnCreate.Text = "Create"
$btnCreate.Name = "btnCreate"
$groupBoxActions.Controls.Add($btnCreate)
$btnCreate.Location = New-Object System.Drawing.Point(5,20)
$btnCreate.Add_Click({
    if ($txtDeploymentName.Text.Trim() -eq "" -or $txtReason.Text.Trim() -eq "" -or ($txtTargetComputersAndUsers.Text.Trim() -eq "" -and $txtTargetADGroups.Text.Trim() -eq "") `
    -or ($checkboxAvailable.Checked -eq $false -and $checkBoxDeadline.Checked -eq $false) -or $lbObjectsToDeploy.Items.Count -eq 0) {
        [System.Windows.Forms.MessageBox]::Show("Please review the submitted form. Some data is missing! Cannot continue.","Deployment creation",[System.Windows.Forms.MessageBoxButtons]::OK,[System.Windows.Forms.MessageBoxIcon]::Warning) 
        return
    }
    
    if ((IsAutoScriptRunning) -eq $true){
        [System.Windows.Forms.MessageBox]::Show("AutoScript is running, please wait until it finishes and retry! Cannot continue.","Deployment creation",[System.Windows.Forms.MessageBoxButtons]::OK,[System.Windows.Forms.MessageBoxIcon]::Warning) 
        return
    }

    $validationResult = validateTargetList
    if ($validationResult -ne $false) {
        $validationResult = $validationResult -join [Environment]::NewLine
        $msgboxResult = [System.Windows.Forms.MessageBox]::Show("Following lines are not correct and will be omitted in target list if you decide to continue: $($validationResult)","Deployment creation",[System.Windows.Forms.MessageBoxButtons]::YesNo,[System.Windows.Forms.MessageBoxIcon]::Information)
        if ($msgboxResult -eq "No") { return }
    }

    if ($btnCreate.Text -eq "Create") {
        $result = createOrModifyXMLdeployment -action "Create"
    } elseif ($btnCreate.Text -eq "Modify"){
        $result = createOrModifyXMLdeployment -action "Modify"
    }

    if ($result -eq $true) { 
        [System.Windows.Forms.MessageBox]::Show("Deployment was created or modified successfully.","Deployment creation",[System.Windows.Forms.MessageBoxButtons]::OK,[System.Windows.Forms.MessageBoxIcon]::Information)
    } else {
        [System.Windows.Forms.MessageBox]::Show("An error occured while creating or modifying the deployment. Please refer to the log file.","Deployment creation",[System.Windows.Forms.MessageBoxButtons]::OK,[System.Windows.Forms.MessageBoxIcon]::Error)
    }
})

$btnLoad = New-Object System.Windows.Forms.Button
$btnLoad.Width = 55
$btnLoad.Height = 25
$btnLoad.Text = "Load"
$btnLoad.Name = "btnLoad"
$groupBoxActions.Controls.Add($btnLoad)
$btnLoad.Location = New-Object System.Drawing.Point(65,20)
$btnLoad.Add_Click({
    if ($btnLoad.Text -eq "Confirm") {
        if ($lbDeployments.SelectedIndex -eq -1) { return }
        defaultFormSettings
        
        
        
        if ((loadDeployment) -eq $false) {
            [System.Windows.Forms.MessageBox]::Show("An error occured while loading the deployment. Please refer to the log file.","Loading the deployment failed",[System.Windows.Forms.MessageBoxButtons]::OK,[System.Windows.Forms.MessageBoxIcon]::Error)
            defaultFormSettings
            return
        }

        $btnDelete.Enabled = $true
        $btnCancel.Enabled = $true
        $btnCreate.Text = "Modify"
        $btnCreate.Enabled = $true
        $btnLoad.Enabled = $false

        if ($txtNextAction.Text -eq "Delete") { $btnDelete.Enabled = $false }
    } else {        
        if ((loadDeployments) -eq $false) { return }
        showDeploymentMenu
    }
})


$btnDelete = New-Object System.Windows.Forms.Button
$btnDelete.Width = 55
$btnDelete.Height = 25
$btnDelete.Text = "Delete"
$btnDelete.Enabled = $false
$btnDelete.Name = "btnDelete"
$groupBoxActions.Controls.Add($btnDelete)
$btnDelete.Location = New-Object System.Drawing.Point(125,20)
$btnDelete.Add_Click({
    if ((IsAutoScriptRunning) -eq $true){
        [System.Windows.Forms.MessageBox]::Show("AutoScript is running, please wait until it finishes and retry! Cannot continue.","Deployment deletion",[System.Windows.Forms.MessageBoxButtons]::OK,[System.Windows.Forms.MessageBoxIcon]::Warning) 
        return
    }

    if ((createOrModifyXMLdeployment -action "Delete") -eq $true) {
        [System.Windows.Forms.MessageBox]::Show("Deployment was deleted successfully.","Deployment deletion",[System.Windows.Forms.MessageBoxButtons]::OK,[System.Windows.Forms.MessageBoxIcon]::Information)
    } else {
        [System.Windows.Forms.MessageBox]::Show("An error occured while deleting the deployment. Please refer to the log file.","Deployment deletion",[System.Windows.Forms.MessageBoxButtons]::OK,[System.Windows.Forms.MessageBoxIcon]::Error)
    }
})

$btnCancel = New-Object System.Windows.Forms.Button
$btnCancel.Width = 55
$btnCancel.Height = 25
$btnCancel.Text = "Cancel"
$btnCancel.Name = "btnCancel" 
$btnCancel.Enabled = $false
$groupBoxActions.Controls.Add($btnCancel)
$btnCancel.Location = New-Object System.Drawing.Point(185,20)
$btnCancel.Add_Click({
    defaultFormSettings
})

$lblChooseDeployment = New-Object System.Windows.Forms.Label
$lblChooseDeployment.AutoSize = $true
$lblChooseDeployment.Text = "Choose a deployment"
$lblChooseDeployment.Visible = $false
$lblChooseDeployment.Location = New-Object System.Drawing.Point(5,270)
$mainForm.Controls.Add($lblChooseDeployment)

$lbDeployments = New-Object System.Windows.Forms.ListBox
$lbDeployments.Width = 245
$lbDeployments.Height = 150
$lbDeployments.Visible = $false
$lbDeployments.Name = "lbDeployments"
$lbDeployments.Location = New-Object System.Drawing.Point(5,290)
$lbDeployments.Add_SelectedIndexChanged({
    #write-host $lbDeployments.SelectedIndex
})
$mainForm.Controls.Add($lbDeployments)

$lblDeploymentName = New-Object System.Windows.Forms.Label
$lblDeploymentName.Text = "Deployment Name"
$lblDeploymentName.Width = 101
$lblDeploymentName.Visible = $true
$lblDeploymentName.Location = New-Object System.Drawing.Point(5,272)
$mainForm.Controls.Add($lblDeploymentName)

$txtDeploymentName = New-Object System.Windows.Forms.TextBox
$txtDeploymentName.Width = 130
$txtDeploymentName.Height = 20
$txtDeploymentName.Visible = $true
$txtDeploymentName.Location = New-Object System.Drawing.Point(120,270)
$mainForm.Controls.Add($txtDeploymentName)

$lblReason = New-Object System.Windows.Forms.Label
$lblReason.Text = "Reason:"
$lblReason.Width = 46
$lblReason.Visible = $true
$lblReason.Location = New-Object System.Drawing.Point(5,297)
$mainForm.Controls.Add($lblReason)

$txtReason = New-Object System.Windows.Forms.TextBox
$txtReason.Width = 165
$txtReason.Height = 20
$txtReason.Visible = $true
$txtReason.Location = New-Object System.Drawing.Point(85,295)
$mainForm.Controls.Add($txtReason)

$lblAvailableDate = New-Object System.Windows.Forms.Label
$lblAvailableDate.Text = "Available date"
$lblAvailableDate.Width = 80
$lblAvailableDate.Visible = $true
$lblAvailableDate.Location = New-Object System.Drawing.Point(5,322)
$mainForm.Controls.Add($lblAvailableDate)

$availableDateTime = New-Object System.Windows.Forms.DateTimePicker
$availableDateTime.Visible = $true
$availableDateTime.Width = 145
$availableDateTime.Enabled = $false
$availableDateTime.Format = [System.Windows.Forms.DateTimePickerFormat]::Custom
$availableDateTime.CustomFormat = "dd. MM. yyyy HH:mm:ss"
$availableDateTime.Location = New-Object System.Drawing.Point(85,320)
$mainForm.Controls.Add($availableDateTime)
$availableDateTime.Add_TextChanged({
    if (($deadlineDateTime.Value -lt $availableDateTime.Value -and $checkBoxDeadline.Checked -eq $true) -and $Global:deploymentLoading -eq $false) {
        $deadlineDateTime.Value = $availableDateTime.Value
        #Get-Date $availableDateTime.Text -Format "dd. MM. yyyy hh:mm:ss"
    }
})

$checkboxAvailable = New-Object System.Windows.Forms.CheckBox
$checkboxAvailable.Width = 15
$checkboxAvailable.Location = New-Object System.Drawing.Point(237,318)
$mainForm.Controls.Add($checkboxAvailable)
$checkboxAvailable.Add_CheckedChanged({
    if ($checkboxAvailable.Checked -eq $true) { 
        $availableDateTime.Enabled = $true
    } else {
        $availableDateTime.Enabled = $false
    }
})

$lblDeadlineDate = New-Object System.Windows.Forms.Label
$lblDeadlineDate.Text = "Deadline date"
$lblDeadlineDate.Width = 80
$lblDeadlineDate.Visible = $true
$lblDeadlineDate.Location = New-Object System.Drawing.Point(5,347)
$mainForm.Controls.Add($lblDeadlineDate)

$checkBoxDeadline = New-Object System.Windows.Forms.CheckBox
$checkBoxDeadline.Width = 15
$checkBoxDeadline.Location = New-Object System.Drawing.Point(237,343)
$mainForm.Controls.Add($checkBoxDeadline)
$checkBoxDeadline.Add_CheckedChanged({
    if ($checkBoxDeadline.Checked -eq $true) { 
        $deadlineDateTime.Enabled = $true
    } else {
        $deadlineDateTime.Enabled = $false
    }
})

$deadlineDateTime = New-Object System.Windows.Forms.DateTimePicker
$deadlineDateTime.Visible = $true
$deadlineDateTime.Width = 145
$deadlineDateTime.Enabled = $false
$deadlineDateTime.Format = [System.Windows.Forms.DateTimePickerFormat]::Custom
$deadlineDateTime.CustomFormat = "dd. MM. yyyy HH:mm:ss"
$deadlineDateTime.Location = New-Object System.Drawing.Point(85,345)
$mainForm.Controls.Add($deadlineDateTime)
$deadlineDateTime.Add_TextChanged({
    if (($deadlineDateTime.Value -lt $availableDateTime.Value -and $checkboxAvailable.Checked -eq $true) -and $Global:deploymentLoading -eq $false) {
        $deadlineDateTime.Value = $availableDateTime.Value
        #Get-Date $availableDateTime.Text -Format "dd. MM. yyyy hh:mm:ss"
    }
})

$lblTargetComputersAndUsers = New-Object System.Windows.Forms.Label
$lblTargetComputersAndUsers.Text = "Target Computers and users"
$lblTargetComputersAndUsers.Width = 150
$lblTargetComputersAndUsers.Visible = $true
$lblTargetComputersAndUsers.Location = New-Object System.Drawing.Point(260,215)
$mainForm.Controls.Add($lblTargetComputersAndUsers)

$txtTargetComputersAndUsers = New-Object System.Windows.Forms.TextBox
$txtTargetComputersAndUsers.Width = 160
$txtTargetComputersAndUsers.Height = 470
$txtTargetComputersAndUsers.Multiline = $true
#$wrap = New-Object System.Windows.TextWrapping
#$wrap.value__ = 0
$txtTargetComputersAndUsers.WordWrap = 0
$txtTargetComputersAndUsers.Name = "txtTargetComputersAndUsers"
$txtTargetComputersAndUsers.ScrollBars = [System.Windows.Forms.ScrollBars]::Vertical
$txtTargetComputersAndUsers.Visible = $true
$txtTargetComputersAndUsers.AcceptsTab = $false
$txtTargetComputersAndUsers.Location = New-Object System.Drawing.Point(260,240)
$mainForm.Controls.Add($txtTargetComputersAndUsers)

$txtTargetComputersAndUsers.Add_TextChanged({
    if ($Global:deploymentLoading -eq $true) { return }

    #check that lines are not too long - 22, AD standard for computer name is 15
    $maxChars = 25
    $toolong = validateLengthOfLines -txtBoxName "txtTargetComputersAndUsers" -maxLength $maxChars
    if ($toolong) {
        $txtTargetComputersAndUsers.Text = "MAX CHARACTER COUNT:$($maxChars)$([Environment]::NewLine)" + $txtTargetComputersAndUsers.Text
    }
})

$txtTargetComputersAndUsers.Add_TextChanged({
    #Write-host "Current line: $($txtTargetComputersAndUsers.GetLineFromCharIndex($txtTargetComputersAndUsers.SelectionStart))"
})

$txtTargetComputersAndUsers.Add_KeyPress({
    #if line is longer than 22 characters $_.Handled = $true
    $currentLine = $($txtTargetComputersAndUsers.GetLineFromCharIndex($txtTargetComputersAndUsers.SelectionStart))
    if ($txtTargetComputersAndUsers.Lines[$currentLine] -notlike "CN:*") {
        #write-host "$($txtTargetComputersAndUsers.Lines[$currentLine].Text) not like CN:"
        $allowedChars = 8,13
        $notAllowedChars = 32
        if ([convert]::ToInt16($_.KeyChar) -in $notAllowedChars) { $_.Handled = $true }
        $maxChars = 25
        if ($txtTargetComputersAndUsers.Lines[$currentLine].Length -ge $maxChars -and [convert]::ToInt32($_.KeyChar) -notin $allowedChars) {
            $_.handled = $true
        }
    }
})

$lblTargetADGroups = New-Object System.Windows.Forms.Label
$lblTargetADGroups.Text = "Target AD groups"
$lblTargetADGroups.Width = 100
$lblTargetADGroups.Visible = $true
$lblTargetADGroups.Location = New-Object System.Drawing.Point(5,370)
$mainForm.Controls.Add($lblTargetADGroups)

$txtTargetADGroups = New-Object System.Windows.Forms.TextBox
$txtTargetADGroups.Width = 245
$txtTargetADGroups.Height = 65
$txtTargetADGroups.Multiline = $true
#$wrap = New-Object System.Windows.TextWrapping
#$wrap.value__ = 0
$txtTargetADGroups.WordWrap = 0
$txtTargetADGroups.Name = "txtTargetADGroups"
$txtTargetADGroups.Visible = $true
$txtTargetADGroups.AcceptsTab = $false
$txtTargetADGroups.ScrollBars = [System.Windows.Forms.ScrollBars]::Vertical
$txtTargetADGroups.Location = New-Object System.Drawing.Point(5,395)
$mainForm.Controls.Add($txtTargetADGroups)

$txtTargetADGroups.Add_TextChanged({
    #check that lines are not too long - 256, ad schema for samaccountname = 256
    if ($Global:deploymentLoading -eq $true) { return }
    $maxChars = 256
    $toolong = validateLengthOfLines -txtBoxName "txtTargetADGroups" -maxLength $maxChars
    if ($toolong) {
        $txtTargetADGroups.Text = "MAX CHARACTER COUNT:$($maxChars)$([Environment]::NewLine)" + $txtTargetADGroups.Text
    }
})

$txtTargetADGroups.Add_TextChanged({
    #Write-host "Current line: $($txtTargetADGroups.GetLineFromCharIndex($txtTargetADGroups.SelectionStart))"
})

$txtTargetADGroups.Add_KeyPress({
    #if line is longer than 22 characters $_.Handled = $true
    $currentLine = $($txtTargetADGroups.GetLineFromCharIndex($txtTargetADGroups.SelectionStart))
    #backspace and enter
    $allowedChars = 8,13
    $maxChars = 256
    if ($txtTargetADGroups.Lines[$currentLine].Length -ge $maxChars -and [convert]::ToInt32($_.KeyChar) -notin $allowedChars) {
        $_.handled = $true
    }
})

$lblNextAction = New-Object System.Windows.Forms.Label
$lblNextAction.Text = "Next Action"
$lblNextAction.Width = 80
$lblNextAction.Visible = $true
$lblNextAction.Location = New-Object System.Drawing.Point(5,472)
$mainForm.Controls.Add($lblNextAction)

$txtNextAction = New-Object System.Windows.Forms.TextBox
$txtNextAction.Width = 165
$txtNextAction.Height = 20
$txtNextAction.Visible = $true
$txtNextAction.Enabled = $false
$txtNextAction.Location = New-Object System.Drawing.Point(85,470)
$mainForm.Controls.Add($txtNextAction)

$lblColID = New-Object System.Windows.Forms.Label
$lblColID.Text = "Collection ID"
$lblColID.Width = 80
$lblColID.Visible = $true
$lblColID.Location = New-Object System.Drawing.Point(5,497)
$mainForm.Controls.Add($lblColID)

$txtColID = New-Object System.Windows.Forms.TextBox
$txtColID.Width = 165
$txtColID.Height = 20
$txtColID.Visible = $true
$txtColID.Enabled = $false
$txtColID.Location = New-Object System.Drawing.Point(85,495)
$mainForm.Controls.Add($txtColID)

$lblColName = New-Object System.Windows.Forms.Label
$lblColName.Text = "Collection Name"
$lblColName.Width = 100
$lblColName.Visible = $true
$lblColName.Location = New-Object System.Drawing.Point(5,522)
$mainForm.Controls.Add($lblColName)

$txtColName = New-Object System.Windows.Forms.TextBox
$txtColName.Width = 130
$txtColName.Height = 20
$txtColName.Visible = $true
$txtColName.Enabled = $false
$txtColName.Location = New-Object System.Drawing.Point(120,520)
$mainForm.Controls.Add($txtColName)

$lblSCCMStatus = New-Object System.Windows.Forms.Label
$lblSCCMStatus.Text = "SCCM Status"
$lblSCCMStatus.Width = 100
$lblSCCMStatus.Visible = $true
$lblSCCMStatus.Location = New-Object System.Drawing.Point(5,547)
$mainForm.Controls.Add($lblSCCMStatus)

$txtSCCMStatus = New-Object System.Windows.Forms.TextBox
$txtSCCMStatus.Width = 130
$txtSCCMStatus.Height = 20
$txtSCCMStatus.Visible = $true
$txtSCCMStatus.Enabled = $false
$txtSCCMStatus.Location = New-Object System.Drawing.Point(120,545)
$mainForm.Controls.Add($txtSCCMStatus)

$lblChangesToDeployment = New-Object System.Windows.Forms.Label
$lblChangesToDeployment.AutoSize = $true
$lblChangesToDeployment.Text = "List of changes"
$lblChangesToDeployment.Visible = $true
$lblChangesToDeployment.Location = New-Object System.Drawing.Point(5,577)
$mainForm.Controls.Add($lblChangesToDeployment)

$lbChangesToDeployment = New-Object System.Windows.Forms.ListBox
$lbChangesToDeployment.Width = 245
$lbChangesToDeployment.Height = 120
$lbChangesToDeployment.Visible = $true
$lbChangesToDeployment.HorizontalScrollbar = $true
$lbChangesToDeployment.Location = New-Object System.Drawing.Point(5,602)
$mainForm.Controls.Add($lbChangesToDeployment)

#settings form part
$settingsForm = New-Object System.Windows.Forms.Form
$settingsForm.Text = "Settings"
$settingsForm.Width = 250
$settingsForm.Height = 200
$settingsForm.Add_Load({ 
    #make sure the form is located in the middle of mainForm
    $settingsForm.Location = New-Object System.Drawing.Point(($mainForm.Location.X + $mainForm.Width/2 - $settingsForm.Width/2),($mainForm.Location.Y + $mainForm.Height/2 - $settingsForm.Height/2))
    if ($Global:settingsObject -ne $false) {
        $txtServerName.Text = $Global:settingsObject.ServerName
        $txtSiteName.Text = $Global:settingsObject.SiteName
        $txtDeviceCollectionPath.Text = $Global:settingsObject.DeviceColPath
        $txtUserCollectionPath.Text = $Global:settingsObject.UserColPath
    } else {

    }
})
$settingsForm.Add_Closing({
    if ($Global:settingsObject -eq $false -or $Global:settingsObject -eq 1) {
        LogToCMTraceFile -message "SettingsObject is not initialized or there was an error readin xml settings file." -type 2 -component "closing"
        $mainForm.Close()
    }
})
$btnSaveSettings = New-Object System.Windows.Forms.Button
$btnSaveSettings.Text = "Save"
$settingsForm.Controls.Add($btnSaveSettings)
$btnSaveSettings.Add_Click({
    if ($txtServerName.Text.Trim() -ne "" -and $txtSiteName.Text.Trim().Length -eq 3 -and $txtDeviceCollectionPath.Text.Trim() -ne "" -and $txtUserCollectionPath.Text.Trim() -ne "") {
        writeSettingsXML -serverName $txtServerName.Text -siteName $txtSiteName.Text -devColPath $txtDeviceCollectionPath.Text -userColPath $txtUserCollectionPath.Text
    }
})

$lblServerName = New-Object System.Windows.Forms.Label
$lblServerName.Text = "Server name"
$lblServerName.AutoSize = $false
$lblServerName.Width = 70
$lblServerName.Location = New-Object System.Drawing.Point(5,10)
$settingsForm.Controls.Add($lblServerName)

$txtServerName = New-Object System.Windows.Forms.TextBox
$txtServerName.Location = New-Object System.Drawing.Point(95,8)
$txtServerName.Width = 120
$txtServerName.Add_KeyPress({
    if ($_.KeyChar -eq " ") {$_.handled=$true}
})
$settingsForm.Controls.Add($txtServerName)

$lblSite = New-Object System.Windows.Forms.Label
$lblSite.Text = "Site name"
$lblSite.AutoSize = $false
$lblSite.Width = 70
$lblSite.Location = New-Object System.Drawing.Point(5,40)
$settingsForm.Controls.Add($lblSite)

$txtSiteName = New-Object System.Windows.Forms.TextBox
$txtSiteName.Location = New-Object System.Drawing.Point(95,38)
$txtSiteName.Width = 120
$txtSiteName.MaxLength = 3
$txtSiteName.Add_KeyPress({
    if ($_.KeyChar -eq " ") {$_.handled=$true}
})
$settingsForm.Controls.Add($txtSiteName)

$lblDeviceCollectionPath = New-Object System.Windows.Forms.Label
$lblDeviceCollectionPath.Text = "Device col. path"
$lblDeviceCollectionPath.AutoSize = $false
$lblDeviceCollectionPath.Width = 85
$lblDeviceCollectionPath.Location = New-Object System.Drawing.Point(5,70)
$settingsForm.Controls.Add($lblDeviceCollectionPath)

$txtDeviceCollectionPath = New-Object System.Windows.Forms.TextBox
$txtDeviceCollectionPath.Location = New-Object System.Drawing.Point(95,68)
$txtDeviceCollectionPath.Width = 120
$settingsForm.Controls.Add($txtDeviceCollectionPath)

$lblUserCollectionPath = New-Object System.Windows.Forms.Label
$lblUserCollectionPath.Text = "User col. path"
$lblUserCollectionPath.AutoSize = $false
$lblUserCollectionPath.Width = 80
$lblUserCollectionPath.Location = New-Object System.Drawing.Point(5,100)
$settingsForm.Controls.Add($lblUserCollectionPath)

$txtUserCollectionPath = New-Object System.Windows.Forms.TextBox
$txtUserCollectionPath.Location = New-Object System.Drawing.Point(95,98)
$txtUserCollectionPath.Width = 120
$settingsForm.Controls.Add($txtUserCollectionPath)

$btnSaveSettings.Location = New-Object System.Drawing.point(($txtUserCollectionPath.Location.X + $txtUserCollectionPath.Width - $btnSaveSettings.Width),($txtUserCollectionPath.Location.Y + 30))
#end settings form part

#menu strip control
$menuBar = New-Object System.Windows.Forms.MenuStrip
$menuBar.Name = "menuBar"
$menuBar.Location = New-Object System.Drawing.Point(0,0)
$menuBar.Width = $mainForm.Width
$menuBar.Height = 25
$mainForm.Controls.Add($menuBar)

#main menu
$newMenu = New-Object System.Windows.Forms.ToolStripMenuItem
$newMenu.Text = "Menu"
#this adds top level item
$menuBar.Items.Add($newMenu) | Out-Null

#settings item that is under MENU option
$newSettingsItem = New-Object System.Windows.Forms.ToolStripMenuItem
$newSettingsItem.Text = "Settings"
$newSettingsItem.Add_Click({
    
    #$settingsForm.StartPosition = "CenterScreen"
    $settingsForm.ShowDialog()
})
$newMenu.DropDownItems.Add($newSettingsItem) | Out-Null


#$control.Add_EVENTNAME({CODEHERE})
#$mainForm.Controls.Add($control)

show

#$mainForm.Controls.Add()

