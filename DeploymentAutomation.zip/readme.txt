In addition to the documentation, please make sure you do not modify created xml files manually.
Also, keep all files together.